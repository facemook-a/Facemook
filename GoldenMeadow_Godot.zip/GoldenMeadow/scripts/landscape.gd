extends RefCounted

const SIZE := 32.0
const STEPS := 16

static func height(x: float, z: float) -> float:
	var rolling := sin(x * 0.018) * cos(z * 0.016) * 5.0 + sin(x * 0.047 + z * 0.015) * 1.7 + cos(z * 0.036 - x * 0.025) * 1.2
	return rolling * smoothstep(10.0, 25.0, Vector2(x, z).length())

static func normal_at(x: float, z: float) -> Vector3:
	return Vector3(height(x - 0.2, z) - height(x + 0.2, z), 0.4, height(x, z - 0.2) - height(x, z + 0.2)).normalized()

static func terrain_mesh(coord: Vector2i) -> ArrayMesh:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for z in range(STEPS):
		for x in range(STEPS):
			for o in [Vector2i(0,0), Vector2i(1,0), Vector2i(0,1), Vector2i(1,0), Vector2i(1,1), Vector2i(0,1)]:
				var wx: float = coord.x * SIZE + (x + o.x) * SIZE / STEPS
				var wz: float = coord.y * SIZE + (z + o.y) * SIZE / STEPS
				st.set_normal(normal_at(wx, wz))
				st.set_uv(Vector2(wx, wz))
				st.add_vertex(Vector3(wx, height(wx,wz), wz))
	return st.commit()

static func grass_mesh() -> ArrayMesh:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for blade in range(7):
		var a := blade * 2.39996
		var right := Vector3(cos(a), 0.0, sin(a))
		var base := right * (0.10+blade*0.022)
		var tall := 0.33 + blade * 0.025
		for seg in range(2):
			var t0 := float(seg) / 2.0
			var t1 := float(seg+1) / 2.0
			var p0 := base + Vector3.UP * t0 * tall + right * t0*t0 * 0.20
			var p1 := base + Vector3.UP * t1 * tall + right * t1*t1 * 0.20
			var w0 := (1.0-t0) * 0.020
			var w1 := (1.0-t1) * 0.020
			var points := [p0-right*w0,p1-right*w1,p0+right*w0,p0+right*w0,p1-right*w1,p1+right*w1]
			var uvs := [Vector2(0,1-t0),Vector2(0,1-t1),Vector2(1,1-t0),Vector2(1,1-t0),Vector2(0,1-t1),Vector2(1,1-t1)]
			for i in range(6):
				st.set_normal(Vector3(0.0,0.65,0.76))
				st.set_uv(uvs[i])
				st.add_vertex(points[i])
	return st.commit()

static func grass_allowed(x: float, z: float) -> bool:
	if absf(x) < 5.8 and absf(z) < 4.6: return false
	if z > 3.0 and z < 34.0 and absf(x-sin(z*0.12)*1.5) < 1.1: return false
	return true
