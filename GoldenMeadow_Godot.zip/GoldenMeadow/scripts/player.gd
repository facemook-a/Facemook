extends CharacterBody3D

var hud: CanvasLayer
var yaw := 0.0
var pitch := -0.10
var pivot: Node3D
var camera: Camera3D
var visual: Node3D
var left_leg: Node3D
var right_leg: Node3D
var left_arm: Node3D
var right_arm: Node3D
var stride := 0.0
var sprinting := false

func _ready() -> void:
	floor_snap_length = 0.5
	floor_max_angle = deg_to_rad(50.0)
	var collision := CollisionShape3D.new()
	var shape := CapsuleShape3D.new()
	shape.radius = 0.32
	shape.height = 1.8
	collision.shape = shape
	collision.position.y = 0.9
	add_child(collision)
	visual = Node3D.new()
	add_child(visual)
	_build_character()
	pivot = Node3D.new()
	pivot.position.y = 1.55
	add_child(pivot)
	var arm := SpringArm3D.new()
	arm.spring_length = 4.3
	arm.margin = 0.2
	arm.add_excluded_object(get_rid())
	pivot.add_child(arm)
	camera = Camera3D.new()
	camera.current = true
	camera.fov = 68.0
	camera.near = 0.12
	camera.far = 210.0
	arm.add_child(camera)

func _mat(color: String) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(color)
	m.roughness = 0.9
	return m

func _capsule(parent: Node3D, pos: Vector3, radius: float, height: float, material: Material) -> MeshInstance3D:
	var node := MeshInstance3D.new()
	var mesh := CapsuleMesh.new()
	mesh.radius = radius
	mesh.height = height
	mesh.radial_segments = 12
	mesh.rings = 4
	node.mesh = mesh
	node.material_override = material
	parent.add_child(node)
	node.position = pos
	return node

func _build_character() -> void:
	var coat := _mat("637c73")
	var trousers := _mat("333b3e")
	var leather := _mat("47392f")
	var scarf := _mat("b27548")
	var skin := _mat("b99675")
	_capsule(visual,Vector3(0,1.12,0),0.27,0.73,coat)
	_capsule(visual,Vector3(0,1.65,0),0.19,0.4,leather)
	_capsule(visual,Vector3(0,1.62,-0.13),0.12,0.23,skin)
	_capsule(visual,Vector3(0,1.44,0),0.22,0.15,scarf)
	_capsule(visual,Vector3(0,1.12,0.27),0.22,0.57,leather)
	for side in [-1,1]:
		var leg := Node3D.new()
		visual.add_child(leg)
		leg.position = Vector3(side*0.135,0.79,0)
		_capsule(leg,Vector3(0,-0.30,0),0.105,0.65,trousers)
		_capsule(leg,Vector3(0,-0.66,-0.06),0.11,0.24,leather)
		var arm := Node3D.new()
		visual.add_child(arm)
		arm.position = Vector3(side*0.3,1.36,0)
		_capsule(arm,Vector3(side*0.015,-0.22,0),0.085,0.53,coat)
		_capsule(arm,Vector3(side*0.015,-0.5,0),0.065,0.15,skin)
		if side == -1:
			left_leg=leg
			left_arm=arm
		else:
			right_leg=leg
			right_arm=arm

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index==MOUSE_BUTTON_RIGHT:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED if event.pressed else Input.MOUSE_MODE_VISIBLE
	if event is InputEventMouseMotion and Input.mouse_mode==Input.MOUSE_MODE_CAPTURED:
		look(event.relative*0.003)
	if event is InputEventKey and event.pressed and event.keycode==KEY_ESCAPE:
		Input.mouse_mode=Input.MOUSE_MODE_VISIBLE

func look(amount: Vector2) -> void:
	yaw -= amount.x
	pitch = clampf(pitch-amount.y,-0.75,0.65)

func _physics_process(delta: float) -> void:
	var movement := Input.get_vector("left","right","forward","back")
	if hud and hud.move_vector.length()>0.0: movement=hud.move_vector
	sprinting = Input.is_action_pressed("sprint") or (hud and hud.sprinting)
	var speed := 7.2 if sprinting else 4.1
	var direction := Basis(Vector3.UP,yaw)*Vector3(movement.x,0,movement.y)
	velocity.x=move_toward(velocity.x,direction.x*speed,delta*24.0)
	velocity.z=move_toward(velocity.z,direction.z*speed,delta*24.0)
	if not is_on_floor(): velocity.y-=18.0*delta
	if (Input.is_action_just_pressed("jump") or (hud and hud.jump_requested)) and is_on_floor(): velocity.y=6.4
	if hud: hud.jump_requested=false
	move_and_slide()
	if position.y < -50.0: get_parent().return_home()
	pivot.rotation=Vector3(pitch,yaw,0)
	var walking := Vector2(velocity.x,velocity.z).length()
	if walking>0.1:
		visual.rotation.y=lerp_angle(visual.rotation.y,atan2(-direction.x,-direction.z),minf(delta*12.0,1.0))
		stride+=delta*walking*2.4
	var amplitude := minf(walking/4.0,1.4)*0.55 if is_on_floor() else 0.2
	left_leg.rotation.x=sin(stride)*amplitude
	right_leg.rotation.x=-sin(stride)*amplitude
	left_arm.rotation.x=-sin(stride)*amplitude*0.7
	right_arm.rotation.x=sin(stride)*amplitude*0.7
	visual.position.y=absf(sin(stride))*amplitude*0.05
