# Validation

Tested using Godot 4.6.3 stable on Linux, with the Compatibility renderer.

- 19 gameplay checks passed in `tests/smoke.gd`: terrain collision, walking, jump/landing, 49 terrain chunks, nine grass chunks, dispatched multitouch movement and camera events, dispatched touch jump button, terrain streaming beyond spawn, unloading old chunks, quality changes, returning home, passing through the cottage doorway, six collectibles, and local JSON persistence.
- `tests/restore.gd` passed in a separate process: saved progress and position restore, and collected lights remain hidden.
- OpenGL rendering was exercised through Mesa llvmpipe on a virtual display. The preview supplied with the project is an actual game capture, not a target render.
- Android hardware performance and Godot 4.7.2 were not tested. The project uses Godot 4 GDScript and Compatibility rendering without plugins or native extensions. Use low quality for weaker phones.

This is a playable prototype with procedural scenery and a simple character model. Its visual quality is inspired by, and does not reproduce the photorealistic reference image. The world streams procedural hills around the player; there is one furnished cottage and six exploration collectibles.
