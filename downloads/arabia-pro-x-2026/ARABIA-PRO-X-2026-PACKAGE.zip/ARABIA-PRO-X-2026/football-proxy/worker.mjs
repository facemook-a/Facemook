/* Cloudflare Worker / API-FOOTBALL adapter. Secrets are server-side only.
   Reads serve a retained KV snapshot; visitors never trigger provider calls. */
const PROVIDER = 'https://v3.football.api-sports.io';
const STATUS = {NS:'scheduled',TBD:'scheduled','1H':'live',HT:'live','2H':'live',ET:'live',BT:'live',P:'live',LIVE:'live',FT:'finished',AET:'finished',PEN:'finished',PST:'postponed',SUSP:'postponed',CANC:'cancelled',ABD:'cancelled',AWD:'finished',WO:'finished'};
const key = 'fixtures:v1';
const isoDate = (base, offset) => { const date=new Date(base);date.setUTCDate(date.getUTCDate()+offset);return date.toISOString().slice(0,10); };
const ids = env => String(env.LEAGUE_IDS || '').split(',').map(v=>v.trim()).filter(v=>/^\d+$/.test(v));
export function normalize(responses, allowed, updatedAt, coverage) {
  const leagues=new Map(), matches=new Map();
  for(const payload of responses) {
    if (!payload || !Array.isArray(payload.response) || (payload.errors && Object.keys(payload.errors).length)) throw new Error('Provider rejected query; previous snapshot retained');
    for(const value of payload.response) {
      const fixture=value.fixture,league=value.league,teams=value.teams;
      if(!fixture || !league || !teams || !allowed.includes(String(league.id)))continue;
      const status=STATUS[fixture.status?.short];const kickoff=new Date(fixture.date);
      if(!status || !Number.isFinite(kickoff.getTime()) || !teams.home?.name || !teams.away?.name)continue;
      leagues.set(String(league.id),{id:String(league.id),name:league.name,logo:league.logo || ''});
      const score=value.goals || {};
      matches.set(String(fixture.id),{id:String(fixture.id),competitionId:String(league.id),kickoff:kickoff.toISOString(),status,sourceStatus:fixture.status.short,
        home:{id:String(teams.home.id),name:teams.home.name,crest:teams.home.logo || ''},away:{id:String(teams.away.id),name:teams.away.name,crest:teams.away.logo || ''},
        score:{home:Number.isInteger(score.home)?score.home:null,away:Number.isInteger(score.away)?score.away:null},matchday:league.round || ''});
    }
  }
  return {version:1,updatedAt,coverage,competitions:[...leagues.values()],matches:[...matches.values()].sort((a,b)=>Date.parse(a.kickoff)-Date.parse(b.kickoff))};
}
export async function refresh(env, fetcher=fetch, now=new Date()) {
  const allowed=ids(env);
  if(!env.FOOTBALL_API_KEY || !env.FOOTBALL_CACHE || !allowed.length)throw new Error('Missing server configuration');
  const past=Math.min(2,Math.max(0,Number(env.PAST_DAYS)||1)), future=Math.min(7,Math.max(1,Number(env.FUTURE_DAYS)||3));
  const responses=[];
  // Sequential bounded requests respect small provider plans. Cron cadence must fit the plan.
  for(let offset=-past;offset<=future;offset++){
    const url=new URL('/fixtures',PROVIDER);url.searchParams.set('date',isoDate(now,offset));url.searchParams.set('timezone','UTC');
    const response=await fetcher(url,{headers:{'x-apisports-key':env.FOOTBALL_API_KEY,Accept:'application/json'},signal:AbortSignal.timeout(15000)});
    if(!response.ok)throw new Error('Provider HTTP '+response.status+'; previous snapshot retained');
    responses.push(await response.json());
  }
  const snapshot=normalize(responses,allowed,new Date(now).toISOString(),{from:isoDate(now,-past),to:isoDate(now,future),timezone:'UTC'});
  const previous=await env.FOOTBALL_CACHE.get(key,'json');
  if(snapshot.competitions.length===0 && previous?.matches?.length) {
    // Legitimate all-empty windows can occur; a new provider error was already rejected above.
    // Keep no fictitious competitions: the frontend shows an honest empty state.
  }
  await env.FOOTBALL_CACHE.put(key,JSON.stringify(snapshot));return snapshot;
}
export default {
  async scheduled(event,env,ctx){ctx.waitUntil(refresh(env));},
  async fetch(request,env){
    const url=new URL(request.url);
    const origin=request.headers.get('Origin');
    const origins=String(env.ALLOWED_ORIGINS || '').split(',').map(v=>v.trim()).filter(Boolean);
    const headers={'Content-Type':'application/json; charset=utf-8','X-Content-Type-Options':'nosniff','Vary':'Origin'};
    if(origin&&!origins.includes(origin))return new Response(JSON.stringify({error:'Origin not allowed'}),{status:403,headers});
    if(origin)headers['Access-Control-Allow-Origin']=origin;
    if(request.method==='OPTIONS')return new Response(null,{status:204,headers:{...headers,'Access-Control-Allow-Methods':'GET, OPTIONS','Access-Control-Allow-Headers':'Accept','Access-Control-Max-Age':'86400'}});
    if(request.method!=='GET')return new Response(JSON.stringify({error:'Method not allowed'}),{status:405,headers:{...headers,Allow:'GET, OPTIONS'}});
    if(url.pathname!=='/fixtures')return new Response(JSON.stringify({error:'Not found'}),{status:404,headers});
    if(!env.FOOTBALL_CACHE)return new Response(JSON.stringify({error:'Server not configured'}),{status:503,headers});
    const snapshot=await env.FOOTBALL_CACHE.get(key);
    if(!snapshot)return new Response(JSON.stringify({error:'Snapshot not available yet'}),{status:503,headers:{...headers,'Retry-After':'120'}});
    // Shared KV snapshot + CDN caching. No visitor calls the provider, even on cache misses.
    headers['Cache-Control']='public, max-age=60, s-maxage=120, stale-while-revalidate=120';
    return new Response(snapshot,{status:200,headers});
  }
};
