/* ARABIA PRO X 2026. No private credentials belong in this file or its config. */
(() => {
  'use strict';
  const $ = (s, root = document) => root.querySelector(s);
  const $$ = (s, root = document) => [...root.querySelectorAll(s)];
  const storage = { get(k) { try { return localStorage.getItem('arx:' + k); } catch { return null; } },
    set(k, v) { try { localStorage.setItem('arx:' + k, v); } catch { /* Storage is optional. */ } } };
  const parse = (text, fallback) => { try { return JSON.parse(text); } catch { return fallback; } };
  const config = parse($('#arx-config')?.textContent || '{}', {});
  // Empty optional Layout gadgets must not leave decorative blank boxes.
  $$('.sidebar .widget').forEach(widget => {
    const content = $('.widget-content', widget);
    if (content && !content.textContent.trim() && !content.querySelector('img,iframe,video,input,button,a')) widget.hidden = true;
  });
  const node = (tag, cls, text) => { const el = document.createElement(tag); if (cls) el.className = cls;
    if (text !== undefined) el.textContent = text; return el; };
  const safeURL = (value, sameOrigin = false) => {
    if (!value || typeof value !== 'string') return '';
    try { const url = new URL(value, location.href);
      if (!['https:', 'http:'].includes(url.protocol) || (location.protocol === 'https:' && url.protocol !== 'https:')) return '';
      if (sameOrigin && url.origin !== location.origin) return ''; return url.href;
    } catch { return ''; }
  };
  const home = new URL($('link[rel=home]')?.href || '/', location.origin);
  const footerDescription=$('[data-site-description]');if(footerDescription)footerDescription.textContent=$('.masthead .brand-caption')?.textContent.trim()||'';
  // Keep native post HTML intact while opening the homepage to a full-width lead grid.
  const featured=$('[data-home-featured]'), featuredSlot=$('[data-home-feature-slot]');
  if(featured && featuredSlot)featuredSlot.append(featured);
  if(featured && !$('.story',featured)){featured.hidden=true;if(featuredSlot)featuredSlot.hidden=true;}
  const updateClock=()=>{
    const now=new Date(),date=$('[data-top-date]'),time=$('[data-top-time]');
    if(date)date.textContent=new Intl.DateTimeFormat('ar-MA',{weekday:'long',day:'numeric',month:'long',year:'numeric'}).format(now);
    if(time){time.textContent=new Intl.DateTimeFormat('ar-MA',{hour:'2-digit',minute:'2-digit',hour12:false}).format(now);time.dateTime=now.toISOString();}
  };updateClock();setInterval(updateClock,60000);
  $$('.social-links .widget').forEach(widget=>{if(!$$('a',widget).length)widget.hidden=true;});
  const topSocial=$('[data-top-social]');
  if(topSocial)$$('.social-list a').slice(0,6).forEach(link=>{const copy=link.cloneNode(true);$('span',copy)?.remove();topSocial.append(copy);});
  const newsCards=$$('body[data-view=home] .editorial-grid > .story'),filterBar=$('[data-news-filter-bar]');
  if(filterBar && newsCards.length){
    const labels=[...new Set(newsCards.map(card=>$('.pill',card)?.textContent.trim()).filter(Boolean))];
    ['الكل',...labels].forEach((label,index)=>{const button=node('button','news-filter',label);button.type='button';button.setAttribute('aria-pressed',String(index===0));
      button.addEventListener('click',()=>{$$('button',filterBar).forEach(b=>b.setAttribute('aria-pressed',String(b===button)));newsCards.forEach(card=>{card.hidden=index!==0&&$('.pill',card)?.textContent.trim()!==label;});});filterBar.append(button);});
    filterBar.hidden=false;
  }
  const toast = (message) => { const target = $('#arx-toast'); if (!target) return;
    target.textContent = message; target.hidden = false; clearTimeout(toast.timer);
    toast.timer = setTimeout(() => { target.hidden = true; }, 3500); };
  const readBookmarks = () => {
    const value=parse(storage.get('bookmarks') || '[]',[]);
    return Array.isArray(value)?value.filter(item=>item && typeof item.title==='string' && safeURL(item.url,true)).slice(0,50):[];
  };
  function showBookmarks() {
    const dialog=$('#bookmarks-dialog'), list=$('[data-bookmarks-list]',dialog); if(!dialog || !list)return;
    list.replaceChildren(); const saved=readBookmarks();
    if(!saved.length) list.append(node('p','status-message','لم تحفظ أي مقالات بعد على هذا المتصفح.'));
    saved.forEach(item=>{const row=node('div','bookmark-row'),link=node('a','',item.title);link.href=safeURL(item.url,true);link.dir='auto';
      const remove=node('button','button','إزالة');remove.type='button';remove.setAttribute('aria-label','إزالة '+item.title);
      remove.addEventListener('click',()=>{storage.set('bookmarks',JSON.stringify(readBookmarks().filter(v=>v.url!==item.url)));document.dispatchEvent(new Event('arx:bookmarks-changed'));showBookmarks();});row.append(link,remove);list.append(row);});
    if(!dialog.open)dialog.showModal();
  }
  $$('[data-bookmarks-open]').forEach(button=>button.addEventListener('click',showBookmarks));

  // Persisted preference remains optional; the head bootstrap prevents a light flash.
  const themeButton = $('[data-theme-toggle]');
  const modes = ['system', 'light', 'dark'];
  const modeNames = {system: 'النظام', light: 'الفاتح', dark: 'الداكن'};
  const updateThemeLabel = () => {
    if (!themeButton) return;
    const selected = document.documentElement.dataset.theme || 'system';
    themeButton.setAttribute('aria-label', 'المظهر: ' + modeNames[selected] + '؛ اضغط للتبديل');
    themeButton.title = themeButton.getAttribute('aria-label');
  };
  themeButton?.addEventListener('click', () => {
    const current = document.documentElement.dataset.theme || 'system';
    const next = modes[(modes.indexOf(current) + 1) % modes.length];
    document.documentElement.dataset.theme = next; storage.set('theme', next); updateThemeLabel();
  }); updateThemeLabel();

  const menuButton = $('[data-menu-toggle]'), nav = $('#primary-navigation'), backdrop = $('#drawer-backdrop');
  const mobileCategories=$('[data-mobile-categories]');
  if(mobileCategories){const homeLink=$('#primary-navigation a');if(homeLink)mobileCategories.append(homeLink.cloneNode(true));$$('.category-nav-links a').forEach(link=>mobileCategories.append(link.cloneNode(true)));}
  const smallScreen = matchMedia('(max-width:860px)');
  const setMenu = (open, focus = false) => {
    if (!nav || !menuButton) return;
    document.documentElement.style.setProperty('--drawer-top',Math.max(0,$('.site-header').getBoundingClientRect().bottom)+'px');
    nav.classList.toggle('open', open); backdrop?.classList.toggle('open', open);
    menuButton.setAttribute('aria-expanded', String(open));
    menuButton.setAttribute('aria-label', open ? 'إغلاق القائمة' : 'فتح القائمة');
    nav.inert = smallScreen.matches && !open;
    document.body.classList.toggle('scroll-lock', open && smallScreen.matches);
    if (focus) (open ? $('a,button', nav) : menuButton)?.focus();
  };
  menuButton?.addEventListener('click', () => setMenu(!nav.classList.contains('open'), true));
  backdrop?.addEventListener('click', () => setMenu(false, true));
  smallScreen.addEventListener('change', () => setMenu(false)); setMenu(false);
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') { if (nav?.classList.contains('open')) setMenu(false, true);
      $$('.explore[open]').forEach(el => { el.open = false; $('summary', el)?.focus(); }); }
    if (event.key === 'Tab' && smallScreen.matches && nav?.classList.contains('open')) {
      const links = [menuButton, ...$$('a,button,summary', nav)].filter(el => !el.hidden);
      const first = links[0], last = links[links.length - 1];
      if (event.shiftKey && document.activeElement === first) { last.focus(); event.preventDefault(); }
      else if (!event.shiftKey && document.activeElement === last) { first.focus(); event.preventDefault(); }
    }
  });
  document.addEventListener('click', event => { $$('.explore[open]').forEach(el => { if (!el.contains(event.target)) el.open = false; }); });
  $$('.primary-nav a').forEach(a => { if (a.href === location.href) a.setAttribute('aria-current', 'page'); });
  const search = $('#search-dialog');
  $('[data-search-open]')?.addEventListener('click', () => { setMenu(false); search?.showModal(); $('input', search)?.focus(); });
  $$('[data-dialog-close]').forEach(button => button.addEventListener('click', () => button.closest('dialog')?.close()));
  $$('dialog').forEach(dialog => dialog.addEventListener('click', event => { if (event.target === dialog) {
    const r = dialog.getBoundingClientRect(); if (event.clientX < r.left || event.clientX > r.right || event.clientY < r.top || event.clientY > r.bottom) dialog.close();
  } }));

  // Real Blogger feeds, with bounded requests and no JSONP execution.
  const feedRequests = new Map();
  async function feed(label, count = 6, order = '') {
    const url = new URL('feeds/posts/summary' + (label ? '/-/' + encodeURIComponent(label) : ''), home);
    url.searchParams.set('alt', 'json'); url.searchParams.set('max-results', Math.min(12, count));
    if (order) url.searchParams.set('orderby', order);
    if (!feedRequests.has(url.href)) feedRequests.set(url.href, (async () => {
      const response = await fetch(url, {signal: AbortSignal.timeout(10000), credentials: 'same-origin'});
      if (!response.ok) throw new Error('feed-unavailable');
      const payload = await response.json();
      if (!payload.feed) throw new Error('feed-invalid');
      return (payload.feed.entry || []).map(entry => {
        const link = entry.link?.find(item => item.rel === 'alternate');
        const parsed = new DOMParser().parseFromString(entry.summary?.$t || '', 'text/html');
        return {title: entry.title?.$t || '', url: safeURL(link?.href || '', true),
          image: safeURL(entry.media$thumbnail?.url || ''), date: entry.published?.$t || '',
          author: entry.author?.[0]?.name?.$t || '', summary: (parsed.body.textContent || '').trim().slice(0, 160)};
      }).filter(post => post.url && post.title);
    })());
    return feedRequests.get(url.href);
  }
  function storyCard(post) {
    const article = node('article', 'story'), media = node('a', 'story-media'); media.href = post.url; media.tabIndex = -1; media.setAttribute('aria-hidden', 'true');
    if (post.image) { const image = node('img'); image.src = post.image; image.alt = ''; image.loading = 'lazy'; image.decoding = 'async'; image.width = 480; image.height = 300; media.append(image); }
    else { media.classList.add('no-image'); media.textContent = 'مقال'; }
    const copy = node('div', 'story-copy'), heading = node('h3'), link = node('a', '', post.title);
    link.href = post.url; link.dir = 'auto'; heading.append(link); copy.append(heading);
    const date = new Date(post.date); if (Number.isFinite(date.getTime())) { const time = node('time', 'story-meta', new Intl.DateTimeFormat('ar', {dateStyle:'medium'}).format(date)); time.dateTime = date.toISOString(); copy.append(time); }
    article.append(media, copy); return article;
  }
  const observedModules = new WeakMap();
  const lazy = 'IntersectionObserver' in window ? new IntersectionObserver(entries => entries.forEach(entry => {
    if (entry.isIntersecting) { lazy.unobserve(entry.target); (observedModules.get(entry.target) || []).forEach(loadModule); }
  }), {rootMargin:'500px'}) : null;
  async function loadModule(module) {
    const label = module.dataset.label || ''; if (!label && !module.hasAttribute('data-related')) return;
    try {
      let posts = await feed(label, Number(module.dataset.count) || 6);
      if (module.hasAttribute('data-related')) posts = posts.filter(post => new URL(post.url).pathname !== location.pathname).slice(0, 3);
      if (!posts.length) return;
      const head = node('div', 'section-heading'), heading = node('h2', '', module.dataset.title || label || 'اقرأ أيضًا'); head.append(heading);
      if (!module.hasAttribute('data-related')) { const all = node('a', '', 'كل المقالات ←'); all.href = new URL('search/label/' + encodeURIComponent(label), home).href; head.append(all); }
      const grid = node('div', 'module-grid'); posts.forEach(post => grid.append(storyCard(post)));
      module.replaceChildren(head, grid); module.classList.add('module'); module.hidden = false;
    } catch { /* Native articles remain available when a feed is unavailable. */ }
  }
  $$('[data-arx-module], [data-related]').forEach(module => { if (lazy) { const target=module.parentElement; const list=observedModules.get(target) || []; list.push(module); observedModules.set(target,list); lazy.observe(target); } else loadModule(module); });
  $$('[data-arx-breaking]').forEach(async root => {
    try { const posts = await feed(root.dataset.label || '', 5); if (!posts.length) return;
      root.replaceChildren(node('span','breaking-label', root.dataset.title || 'في الواجهة'));
      const links = node('div','breaking-headlines'); posts.forEach((post,index) => { const a = node('a','',post.title); a.href = post.url; a.dir = 'auto'; a.hidden=index!==0;links.append(a); });
      const controls=node('div','ticker-controls');let current=0;
      [['الخبر السابق',-1,'‹'],['الخبر التالي',1,'›']].forEach(([label,step,symbol])=>{const button=node('button','',symbol);button.type='button';button.setAttribute('aria-label',label);button.addEventListener('click',()=>{current=(current+step+posts.length)%posts.length;[...links.children].forEach((link,index)=>link.hidden=index!==current);});controls.append(button);});
      root.append(links,controls); root.classList.add('breaking'); root.hidden = false;
    } catch { /* Entire unconfigured/unavailable strip stays hidden. */ }
  });
  $$('[data-arx-latest]').forEach(async root=>{
    try{const posts=await feed('',Number(root.dataset.count)||5);if(!posts.length)return;
      root.append(node('h2','',root.dataset.title||'أحدث المقالات'));const list=node('div','rail-stories');posts.forEach(post=>list.append(storyCard(post)));root.append(list);root.hidden=false;
    }catch{/* This optional rail stays absent when the real feed is unavailable. */}
  });

  // Reading tools enhance real server-rendered articles and static pages.
  const body = $('.post-body'), article = $('article.post');
  if (body && article) {
    const plain = body.textContent.trim();
    const minutes = Math.max(1, Math.ceil(plain.split(/\s+/u).filter(Boolean).length / 200));
    const reading = $('[data-reading-time]'); if (reading) { reading.textContent = minutes + ' دقائق قراءة'; reading.hidden = false; }
    const headings = $$('h2,h3',body).filter(h => h.textContent.trim());
    if (headings.length >= 3) { const toc = node('details','toc'); toc.open = false;
      toc.append(node('summary','','في هذا المقال')); const list = node('ol');
      const ids = new Set($$('[id]').map(el => el.id));
      headings.forEach((heading, index) => { if (!heading.id) { let id = 'arx-heading-' + index; while(ids.has(id)) id += '-x'; heading.id = id; ids.add(id); }
        const li = node('li', heading.tagName === 'H3' ? 'sub' : ''); const a = node('a','',heading.textContent); a.href = '#' + encodeURIComponent(heading.id); li.append(a); list.append(li); });
      toc.append(list); body.before(toc);
    }
    $$('table', body).forEach(table => { if (table.parentElement.classList.contains('table-scroll')) return;
      const wrap = node('div','table-scroll'); wrap.tabIndex = 0; wrap.setAttribute('role','region'); wrap.setAttribute('aria-label','جدول قابل للتمرير أفقيًا'); table.before(wrap); wrap.append(table); });
    $$('img', body).forEach((image, i) => { if (i > 0) image.loading = 'lazy'; image.decoding = 'async';
      // Preserve an image's genuine linked destination; lightbox unlinked images only.
      if (!image.closest('a')) { image.tabIndex = 0; image.setAttribute('role','button'); image.setAttribute('aria-label','تكبير الصورة: ' + (image.alt || 'صورة المقال'));
        const open = () => { const lightbox = $('#image-lightbox'), target = $('img', lightbox); if (!lightbox || !target) return;
          target.src = image.currentSrc || image.src; target.alt = image.alt; $('p',lightbox).textContent = image.alt; lightbox.showModal(); };
        image.addEventListener('click',open); image.addEventListener('keydown',e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); } }); }
    });
    let size = Number(storage.get('font-size')) || 19; size = Math.min(24,Math.max(17,size));
    const setSize = () => document.documentElement.style.setProperty('--reading-size', size + 'px'); setSize();
    $$('[data-font-size]').forEach(button => button.addEventListener('click', () => { size = Math.min(24,Math.max(17,size + Number(button.dataset.fontSize))); setSize(); storage.set('font-size',String(size)); toast('حجم الخط: ' + size); }));
    const canonical = $('link[rel=canonical]')?.href || location.href.split('#')[0], title = $('.post-title')?.textContent.trim() || document.title;
    $('[data-copy-link]')?.addEventListener('click',async () => {
      try { if (!navigator.clipboard) throw new Error('clipboard'); await navigator.clipboard.writeText(canonical); toast('نُسخ رابط المقال'); }
      catch { const input = node('textarea'); input.value = canonical; input.style.position='fixed'; input.style.opacity='0'; document.body.append(input); input.select();
        const success = document.execCommand('copy'); input.remove(); toast(success ? 'نُسخ رابط المقال' : 'تعذّر النسخ؛ انسخ الرابط من شريط العنوان'); }
    });
    const nativeShare = $('[data-native-share]'); if (nativeShare && navigator.share) { nativeShare.hidden = false; nativeShare.addEventListener('click',async () => { try { await navigator.share({title,url:canonical}); } catch { /* Cancel is normal. */ } }); }
    const shareLinks = {whatsapp:'https://wa.me/?text=' + encodeURIComponent(title + ' ' + canonical), x:'https://twitter.com/intent/tweet?text=' + encodeURIComponent(title) + '&url=' + encodeURIComponent(canonical)};
    $$('[data-share]').forEach(a => { a.href = shareLinks[a.dataset.share]; a.hidden = false; });
    const bookmark = $('[data-bookmark]');
    if (bookmark) { let saved = readBookmarks();
      const update = () => { const active = saved.some(item => item.url === canonical); bookmark.setAttribute('aria-pressed',String(active)); bookmark.textContent = active ? 'أُضيف إلى المحفوظات' : 'حفظ للقراءة لاحقًا'; }; update();
      bookmark.addEventListener('click',() => { saved = saved.some(item => item.url === canonical) ? saved.filter(item => item.url !== canonical) : [{url:canonical,title},...saved].slice(0,50); storage.set('bookmarks',JSON.stringify(saved)); update(); toast('المحفوظات متاحة على هذا المتصفح فقط'); });
      document.addEventListener('arx:bookmarks-changed',()=>{saved=readBookmarks();update();});
    }
    // Schema is JSON-serialized from actual Blogger-rendered values, never string interpolation.
    const date = $('time[datetime]',article)?.dateTime, author = $('.author-name',article), image = $('img',body);
    if (article.dataset.kind === 'post' && date && Number.isFinite(Date.parse(date))) {
      const schema = {'@context':'https://schema.org','@type':'BlogPosting',headline:title,url:canonical,mainEntityOfPage:{'@type':'WebPage','@id':canonical},datePublished:date,inLanguage:document.documentElement.lang || 'ar'};
      if (author?.textContent.trim()) { schema.author = {'@type':'Person', name:author.textContent.trim()}; if (author.href) schema.author.url = author.href; }
      if (image && safeURL(image.src)) schema.image = [safeURL(image.src)];
      const ld = node('script'); ld.type = 'application/ld+json'; ld.textContent = JSON.stringify(schema); document.head.append(ld);
      const crumbs = $$('.breadcrumbs a', article).map((a,i) => ({'@type':'ListItem',position:i+1,name:a.textContent.trim(),item:a.href}));
      crumbs.push({'@type':'ListItem',position:crumbs.length+1,name:title,item:canonical});
      const bread = node('script'); bread.type='application/ld+json'; bread.textContent=JSON.stringify({'@context':'https://schema.org','@type':'BreadcrumbList',itemListElement:crumbs}); document.head.append(bread);
    }
  }
  if (document.body.dataset.view === 'home') { const script = node('script'); script.type='application/ld+json'; script.textContent=JSON.stringify({'@context':'https://schema.org','@type':'WebSite',name:$('.brand-title')?.textContent.trim() || document.title,url:home.href,inLanguage:'ar'}); document.head.append(script); }
  const progress = $('#reading-progress'), topButton = $('[data-to-top]'); let ticking = false;
  const scroll = () => { const y = scrollY; if (topButton) topButton.hidden = y < 600;
    if (body && progress) { const start = body.getBoundingClientRect().top + y; const total = Math.max(1,body.offsetHeight - innerHeight * .4); progress.style.width = Math.min(100,Math.max(0,(y + 100 - start) / total * 100)) + '%'; }
    ticking = false; };
  addEventListener('scroll',() => { if (!ticking) { ticking=true; requestAnimationFrame(scroll); } },{passive:true}); addEventListener('resize',scroll); scroll();
  topButton?.addEventListener('click',() => scrollTo({top:0,behavior:matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth'}));
  const year = $('[data-year]'); if (year) year.textContent=String(new Date().getFullYear());

  // Native Layout sections live outside Blog1, then move to documented reading anchors.
  const moveSection = (id, target) => { const section = document.getElementById(id); if (section && target) target.append(section); };
  if (document.body.dataset.view === 'home') {
    moveSection('featuredAds',$('[data-ad-anchor=featured]'));
    moveSection('groupAds',$('[data-ad-anchor=groups]'));
  }
  if (article?.dataset.kind === 'post' && body) {
    moveSection('articleIntroAds',$('[data-ad-anchor=intro]'));
    const paragraphs = $$(':scope > p',body).filter(p => p.textContent.trim().length > 80);
    if (paragraphs.length >= 10) { const anchor = node('div'); paragraphs[5].after(anchor); moveSection('articleInlineAds',anchor); }
    moveSection('articleBelowAds',$('[data-ad-anchor=below]'));
  }
  // Explicit publisher configuration + a real CMP integration gate. No decorative banner.
  let adsStarted = false;
  function enableAds() {
    if (adsStarted || !config.ads?.enabled || !/^ca-pub-\d{16}$/.test(config.ads.publisher || '')) return;
    if (!['manual','auto'].includes(config.ads.mode)) return;
    adsStarted=true; const client=config.ads.publisher;
    const already=$('script[src*="pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"]');
    if (!already) { const script=node('script'); script.async=true; script.crossOrigin='anonymous'; script.src='https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=' + client; document.head.append(script); }
    if (config.ads.mode !== 'manual') return;
    $$('.arx-ad[data-ad-slot]').forEach(slot => {
      if (slot.closest('.ad-staging') || !/^\d{6,20}$/.test(slot.dataset.adSlot || '') || slot.dataset.initialized) return;
      slot.dataset.initialized='true'; slot.hidden=false;
      const gadget=slot.closest('.widget'); if (gadget) gadget.hidden=false;
      const label=node('span','ad-label','إعلان'); const ins=node('ins','adsbygoogle'); ins.style.display='block';
      ins.dataset.adClient=client; ins.dataset.adSlot=slot.dataset.adSlot; ins.dataset.adFormat='auto'; ins.dataset.fullWidthResponsive='true';
      slot.replaceChildren(label,ins);
      try { (window.adsbygoogle=window.adsbygoogle || []).push({}); } catch { slot.hidden=true; }
    });
  }
  window.ARX = Object.freeze({enableAds});
  addEventListener('arx:ads-consent-granted', enableAds);
  if (window.ARX_ADS_ALLOWED === true) enableAds();

  // Optional, genuine football data. No endpoint means no visible football UI.
  const football = config.football || {}, centers = $$('[data-arx-fixtures]');
  if (!['proxy','public'].includes(football.mode) || !football.endpoint || !centers.length) return;
  let endpoint; try { endpoint=new URL(football.endpoint); if (endpoint.protocol !== 'https:' || endpoint.username || endpoint.password || endpoint.searchParams.has('key') || endpoint.searchParams.has('token') || endpoint.searchParams.has('api_key')) return; } catch { return; }
  const supportedTimeZone = value => { try { new Intl.DateTimeFormat('ar',{timeZone:value}).format(); return true; } catch { return false; } };
  let zone=storage.get('timezone') || Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC'; if (!supportedTimeZone(zone)) zone='UTC';
  const dayKey = (time, timeZone=zone) => { const parts=new Intl.DateTimeFormat('en-CA',{timeZone,year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date(time));
    return ['year','month','day'].map(type => parts.find(p=>p.type===type)?.value).join('-'); };
  const addDays = (date, amount) => { const value=new Date(date+'T12:00:00Z'); value.setUTCDate(value.getUTCDate()+amount); return value.toISOString().slice(0,10); };
  let selectedDate=dayKey(Date.now()), selectedLeague='', upcoming=false, liveOnly=false;
  let favorites=parse(storage.get('teams') || '[]',[]); if (!Array.isArray(favorites)) favorites=[];
  let favoritesOnly=false, data=null, error='', loading=false;
  const labels={scheduled:'لم تبدأ',live:football.realtime === true ? 'مباشر' : 'جارية حسب آخر تحديث',finished:'انتهت',postponed:'تأجلت',cancelled:'ألغيت'};
  const imageURL = value => { const url=safeURL(value || ''); if (!url) return ''; try { return (football.crestHosts || []).includes(new URL(url).hostname) ? url : ''; } catch { return ''; } };
  function validate(payload) {
    if (!payload || !Array.isArray(payload.matches) || !Array.isArray(payload.competitions) || !Number.isFinite(Date.parse(payload.updatedAt))) throw new Error('صيغة بيانات المصدر غير صالحة');
    const competitions=payload.competitions.filter(c=>c && typeof c.id==='string' && typeof c.name==='string').slice(0,100);
    const ids=new Set(competitions.map(c=>c.id)), seen=new Set();
    const matches=payload.matches.filter(m => {
      if (!m || typeof m.id!=='string' || seen.has(m.id) || !ids.has(m.competitionId) || !labels[m.status] || !/^\d{4}-\d{2}-\d{2}T.+(?:Z|[+-]\d{2}:\d{2})$/.test(m.kickoff || '') || !Number.isFinite(Date.parse(m.kickoff))) return false;
      if (![m.home,m.away].every(t=>t && typeof t.id==='string' && typeof t.name==='string')) return false;
      if ((football.allowedCompetitionIds || []).length && !football.allowedCompetitionIds.includes(m.competitionId)) return false;
      seen.add(m.id); return true;
    }).slice(0,500);
    if (payload.matches.length && !matches.length) throw new Error('لا توجد مباريات صالحة ضمن البطولات المسموح بها');
    return {updatedAt:payload.updatedAt,competitions,matches,coverage:payload.coverage || null};
  }
  const cacheKey='football:' + endpoint.href;
  const cached=parse(storage.get(cacheKey) || 'null',null);
  if (cached) try { data=validate(cached.payload); } catch { /* Ignore malformed storage. */ }
  function updateLists() {
    centers.forEach(root => { const select=$('[data-league]',root); if (!select) return;
      select.replaceChildren(new Option('جميع البطولات',''));
      const available=new Set((data?.matches || []).map(m=>m.competitionId));
      (data?.competitions || []).filter(c=>available.has(c.id)).forEach(c=>select.append(new Option(c.name,c.id))); select.value=selectedLeague;
    });
  }
  const controllers=[];
  centers.forEach((root,index) => {
    const compact=root.dataset.arxFixtures==='compact'; root.className='fixture-center'+(compact?' compact':''); root.hidden=false;
    const head=node('div','fixture-head'), titleWrap=node('div'); titleWrap.append(node('span','eyebrow','الملعب'),node('h2','','مركز المباريات'));
    head.append(titleWrap);
    if (compact && safeURL(football.fixturesPage,true)) { const link=node('a','button','كل المباريات ←'); link.href=safeURL(football.fixturesPage,true); head.append(link); }
    const controls=node('div','fixture-controls');
    const makeLabel=(text,input)=>{const label=node('label','',text);label.append(input);controls.append(label);return input;};
    const league=node('select'); league.dataset.league=''; makeLabel('البطولة',league); league.addEventListener('change',()=>{selectedLeague=league.value;renderAll();});
    const timezone=node('select');
    [...new Set([zone,'Africa/Casablanca','Africa/Cairo','Asia/Riyadh','Asia/Dubai','Europe/Paris','UTC'])].filter(supportedTimeZone).forEach(t=>timezone.append(new Option(t,t))); timezone.value=zone;
    makeLabel('المنطقة الزمنية',timezone); timezone.addEventListener('change',()=>{zone=timezone.value;storage.set('timezone',zone);selectedDate=dayKey(Date.now());upcoming=false;controllers.forEach(c=>c.timezone.value=zone);renderAll();});
    const date=node('input'); date.type='date'; date.value=selectedDate; makeLabel('تاريخ المباريات',date); date.addEventListener('change',()=>{if(date.value){selectedDate=date.value;upcoming=false;renderAll();}});
    const tabs=node('div','fixture-tabs'); tabs.setAttribute('role','group'); tabs.setAttribute('aria-label','اختيار يوم المباريات');
    [['اليوم',0],['غدًا',1],['أمس',-1],['القادمة','upcoming']].forEach(([label,offset])=>{const button=node('button','',label); button.type='button'; button.dataset.day=String(offset); button.addEventListener('click',()=>{liveOnly=false;upcoming=offset==='upcoming';selectedDate=addDays(dayKey(Date.now()),upcoming?0:offset);renderAll();});tabs.append(button);});
    const liveButton=node('button','','مباشر');liveButton.type='button';liveButton.dataset.live='';liveButton.hidden=true;liveButton.addEventListener('click',()=>{liveOnly=!liveOnly;upcoming=false;renderAll();});tabs.append(liveButton);
    const favoritesButton=node('button','','فرقي'); favoritesButton.type='button';favoritesButton.dataset.favorites='';favoritesButton.setAttribute('aria-pressed','false');favoritesButton.addEventListener('click',()=>{favoritesOnly=!favoritesOnly;renderAll();});tabs.append(favoritesButton);
    const list=node('div','fixture-list'); list.setAttribute('aria-live','polite');
    const warning=node('div','fixture-error'); warning.setAttribute('role','status');
    const bottom=node('div','fixture-bottom'), updated=node('span'), refresh=node('button','button','تحديث البيانات');refresh.type='button';refresh.addEventListener('click',()=>load(true));bottom.append(updated,refresh);
    root.replaceChildren(head,controls,tabs,warning,list,bottom); controllers.push({root,compact,list,warning,updated,refresh,league,timezone,date});
  });
  function renderAll() {
    controllers.forEach(c=>{
      c.warning.textContent=error; c.warning.hidden=!error; c.refresh.disabled=loading;
      c.date.value=selectedDate; c.league.value=selectedLeague;
      $$('[data-day]',c.root).forEach(b=>b.setAttribute('aria-pressed',String(!liveOnly&&(b.dataset.day==='upcoming'?upcoming:!upcoming && addDays(dayKey(Date.now()),Number(b.dataset.day))===selectedDate))));
      const liveButton=$('[data-live]',c.root),fresh=data&&Date.now()-Date.parse(data.updatedAt)<=Math.max(60,Number(football.staleAfterSeconds)||300)*1000;
      const liveCount=football.realtime===true&&fresh?(data?.matches||[]).filter(m=>m.status==='live').length:0;
      if(liveButton){liveButton.hidden=!liveCount;liveButton.textContent='مباشر الآن ('+liveCount+')';liveButton.setAttribute('aria-pressed',String(liveOnly));}
      $('[data-favorites]',c.root)?.setAttribute('aria-pressed',String(favoritesOnly));
      c.list.replaceChildren();
      let matches=(data?.matches || []).filter(m=>liveOnly?m.status==='live'&&fresh:upcoming?Date.parse(m.kickoff)>Date.now() && m.status==='scheduled':dayKey(m.kickoff)===selectedDate);
      if (selectedLeague) matches=matches.filter(m=>m.competitionId===selectedLeague);
      if (favoritesOnly) matches=matches.filter(m=>favorites.includes(m.home.id)||favorites.includes(m.away.id));
      matches.sort((a,b)=>Date.parse(a.kickoff)-Date.parse(b.kickoff));if(c.compact) matches=matches.slice(0,4);
      if(!matches.length) c.list.append(node('div','fixture-empty',!data?(error?'المباريات غير متاحة حاليًا.':'جارٍ جلب بيانات المباريات…'):favoritesOnly?'لا مباريات للفرق المتابعة في هذا الاختيار.':'لا توجد مباريات متاحة لهذا الاختيار ضمن تغطية المصدر.'));
      let leagueId='';
      for(const match of matches){const competition=data.competitions.find(l=>l.id===match.competitionId);
        if(leagueId!==competition.id){const league=node('div','fixture-league');const logo=imageURL(competition.logo);if(logo){const img=node('img');img.src=logo;img.alt='';img.loading='lazy';league.append(img);}league.append(node('span','',competition.name));c.list.append(league);leagueId=competition.id;}
        const row=node('div','fixture-row');
        const team=(value,away)=>{const el=node('div','fixture-team'+(away?' away':''));const crest=imageURL(value.crest);if(crest){const img=node('img');img.src=crest;img.alt='';img.loading='lazy';img.width=28;img.height=28;el.append(img);}const name=node('span','',value.name);name.dir='auto';el.append(name);return el;};
        const score=node('div','fixture-score');const known=Number.isInteger(match.score?.home)&&match.score.home>=0&&Number.isInteger(match.score?.away)&&match.score.away>=0;
        score.append(node('span','',['live','finished'].includes(match.status)&&known?match.score.home+' – '+match.score.away:new Intl.DateTimeFormat('ar-MA',{timeZone:zone,hour:'2-digit',minute:'2-digit',hour12:false}).format(new Date(match.kickoff))));
        score.append(node('span','fixture-status'+(match.status==='live'&&football.realtime===true&&Date.now()-Date.parse(data.updatedAt)<=Math.max(60,Number(football.staleAfterSeconds)||300)*1000?' live':''),match.status==='live'&&Date.now()-Date.parse(data.updatedAt)>Math.max(60,Number(football.staleAfterSeconds)||300)*1000?'جارية حسب آخر تحديث':labels[match.status]));
        if(match.status==='scheduled'){const seconds=Math.floor((Date.parse(match.kickoff)-Date.now())/1000);if(seconds>0){const note=node('span','fixture-note',seconds<3600?'بعد '+Math.ceil(seconds/60)+' د':seconds<86400?'بعد '+Math.floor(seconds/3600)+' س':'بعد '+Math.floor(seconds/86400)+' ي');score.append(note);}}
        if(match.matchday) score.append(node('span','fixture-note',String(match.matchday)));
        const follow=node('button','favorite-match','☆');follow.type='button';const active=favorites.includes(match.home.id)&&favorites.includes(match.away.id);follow.textContent=active?'★':'☆';follow.setAttribute('aria-label',(active?'إلغاء متابعة ':'متابعة ')+match.home.name+' و'+match.away.name);follow.setAttribute('aria-pressed',String(active));
        follow.addEventListener('click',()=>{favorites=active?favorites.filter(id=>id!==match.home.id&&id!==match.away.id):[...new Set([...favorites,match.home.id,match.away.id])];storage.set('teams',JSON.stringify(favorites));renderAll();});
        if(c.compact)row.append(node('div','fixture-mini-league',competition.name));
        row.append(team(match.home,false),score,team(match.away,true),follow);c.list.append(row);
      }
      c.updated.textContent=data?'تحديث المصدر: '+new Intl.DateTimeFormat('ar',{timeZone:zone,dateStyle:'short',timeStyle:'short'}).format(new Date(data.updatedAt))+' · '+(football.sourceName||'المصدر المحدد')+' · '+zone:'لم تصل بيانات صالحة بعد';
    });
  }
  let lastFetch=cached?.fetchedAt || 0;
  const minInterval=Math.max(60,Math.min(3600,Number(football.pollSeconds)||120))*1000;
  async function load(userAction=false){
    if(loading)return;if(Date.now()-lastFetch<minInterval && data){if(userAction)toast('البيانات مخزنة مؤقتًا؛ حاول بعد قليل');return;}
    loading=true;renderAll();
    try { const response=await fetch(endpoint.href,{credentials:'omit',signal:AbortSignal.timeout(12000),headers:{Accept:'application/json'}});if(!response.ok)throw new Error('تعذّر الاتصال بالمصدر ('+response.status+')');
      const payload=await response.json();data=validate(payload);lastFetch=Date.now();error='';
      const record=JSON.stringify({payload:data,fetchedAt:lastFetch});if(record.length<250000)storage.set(cacheKey,record);updateLists();
    }catch(e){error='تعذّر تحديث المباريات. '+(data?'تُعرض آخر بيانات متاحة مع توقيتها.':'تحقق من المصدر أو حاول لاحقًا.');if(!data)controllers.forEach(c=>c.list.replaceChildren(node('div','fixture-empty','المباريات غير متاحة حاليًا.')));}
    finally{loading=false;renderAll();}
  }
  updateLists();renderAll();load();
  if(football.mode==='proxy'&&football.realtime===true)setInterval(()=>{if(!document.hidden)load();},minInterval);
  // Countdown text derives solely from supplied UTC kickoff times.
  setInterval(()=>{if(!document.hidden&&data)renderAll();},60000);
})();
