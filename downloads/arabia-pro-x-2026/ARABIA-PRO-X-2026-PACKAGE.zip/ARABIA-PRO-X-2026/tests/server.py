from http.server import BaseHTTPRequestHandler, HTTPServer
import json
from pathlib import Path
from urllib.parse import urlparse,parse_qs
from render import render
ROOT=Path(__file__).resolve().parents[1]
class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        url=urlparse(self.path);query=parse_qs(url.query)
        self.send_response(200)
        if url.path=='/test-image.svg':
            self.send_header('Content-Type','image/svg+xml');self.end_headers()
            self.wfile.write(b'<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="625" viewBox="0 0 1000 625"><rect width="1000" height="625" fill="#1264d8"/><circle cx="650" cy="200" r="180" fill="#08b8c8"/><path d="M0 625 400 130 800 625Z" fill="#14243a"/><path d="m400 625 330-350 270 350" fill="#ffb547"/></svg>');return
        if url.path.startswith('/feeds/'):
            entries=[{'title':{'$t':t},'link':[{'rel':'alternate','href':'http://127.0.0.1:8765/post.html'}],'summary':{'$t':'<p>محتوى اصطناعي للفحص المحلي.</p>'},'published':{'$t':'2026-10-29T09:00:00Z'},'author':[{'name':{'$t':'كاتب اختبار'}}],'media$thumbnail':{'url':'http://127.0.0.1:8765/test-image.svg'}} for t in ['أفكار تصنع أثرًا في مستقبل المدن','قراءة في التحولات الاقتصادية','مساحات جديدة للإبداع العربي','حين تصبح المعرفة قوة']]
            self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(json.dumps({'feed':{'entry':entries}}).encode());return
        if url.path=='/comment-frame':
            self.send_header('Content-Type','text/html');self.end_headers();self.wfile.write('<p>بديل محلي لإطار Blogger؛ إرسال التعليقات غير مختبر هنا.</p>'.encode());return
        view='home'
        if url.path=='/post.html':view='post'
        elif url.path=='/p/matches.html':view='matches'
        elif url.path=='/p/about.html':view='page'
        elif url.path.startswith('/search/label/'):view='label'
        elif url.path.startswith('/search'):view='search'
        elif url.path=='/archive.html':view='archive'
        elif url.path=='/404.html':view='404'
        content=render(view,football='football' in query,ads=query.get('ads',[''])[0],public='public' in query)
        self.send_header('Content-Type','text/html; charset=utf-8');self.end_headers();self.wfile.write(content.encode())
    def log_message(self,*args):pass
HTTPServer(('127.0.0.1',8765),Handler).serve_forever()
