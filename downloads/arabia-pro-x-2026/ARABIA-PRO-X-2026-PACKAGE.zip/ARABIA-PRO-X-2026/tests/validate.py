"""Structural/syntax checks only; this does not validate Blogger's server compiler."""
from pathlib import Path
import json
import re
import subprocess
import tempfile
import xml.etree.ElementTree as E
import tinycss2

ROOT=Path(__file__).resolve().parents[1]
B='{http://www.google.com/2005/gml/b}'
H='{http://www.w3.org/1999/xhtml}'
results=[]
def check(value,message):
    assert value,message
    results.append(message)
    print('PASS',message)
source=(ROOT/'ARABIA-PRO-X-2026.xml').read_text()
root=E.fromstring(source)
check(root.tag==H+'html','Standalone Blogger XML is well formed with correct namespaces')
ids=[el.get('id') for el in root.iter() if el.get('id') and el.tag!=B+'includable']
check(len(ids)==len(set(ids)),'Static IDs are unique')
parents={child:parent for parent in root.iter() for child in parent}
sections=list(root.iter(B+'section'))
check(len(sections)==20,'All 20 native Layout regions are present')
for section in sections:
    check(all(child.tag==B+'widget' for child in section),'Section '+section.get('id')+' contains only native widgets')
    ancestor=parents.get(section)
    while ancestor is not None:
        assert ancestor.tag not in [B+'section',B+'widget'],'Nested Layout region'
        ancestor=parents.get(ancestor)
check(True,'Layout sections never nest inside other sections or widgets')
widgets=list(root.iter(B+'widget'))
check(all(re.fullmatch('[A-Za-z][A-Za-z0-9]*',w.get('id')) for w in widgets),'Widget IDs use native alphanumeric form')
check(len([w for w in widgets if w.get('type')=='Blog'])==1,'One native Blog widget drives content')
for widget in widgets:
    includes={inc.get('id') for inc in widget.findall(B+'includable')}
    assert 'main' in includes
    for include in widget.iter(B+'include'):assert include.get('name') in includes,include.attrib
check(True,'All custom widget includes resolve locally')
for index,script in enumerate(root.iter(H+'script')):
    if script.get('type')=='application/ld+json':continue
    if not script.text:continue
    with tempfile.NamedTemporaryFile(suffix='.js',mode='w') as file:
        file.write(script.text);file.flush()
        subprocess.run(['node','--check',file.name],check=True,capture_output=True,text=True)
check(True,'Every bundled executable script passes node --check')
css=root.find('.//'+B+'skin').text
for key,value in {'keycolor':'#1264d8','accentcolor':'#087f8c','backgroundcolor':'#f7f9fc'}.items():css=css.replace('$('+key+')',value)
rules=tinycss2.parse_stylesheet(css,skip_comments=True,skip_whitespace=True)
def validate_rules(rules):
    for rule in rules:
        assert rule.type!='error',str(rule)
        if rule.type=='qualified-rule':
            for declaration in tinycss2.parse_declaration_list(rule.content,skip_comments=True,skip_whitespace=True):
                assert declaration.type!='error',str(declaration)
        elif rule.type=='at-rule' and rule.content:
            if rule.lower_at_keyword in ['media','supports','layer']:
                validate_rules(tinycss2.parse_rule_list(rule.content,skip_comments=True,skip_whitespace=True))
validate_rules(rules)
check(True,'CSS rules and declarations parse without syntax errors')
config_widget=next(w for w in widgets if w.get('id')=='HTML1')
content=config_widget.find('.//'+B+'widget-setting').text
config=json.loads(re.search(r'<script[^>]*>(.*?)</script>',content,re.S)[1])
check(config['ads']['enabled'] is False and config['football']['mode']=='off','Integrations are disabled with no publisher, endpoint or API secrets')
check(not re.search(r'href=[\'"](?:#|javascript:)',source.replace('href="#main-content"','')),'No placeholder or JavaScript navigation links in production markup')
check('فريق اختبار' not in source and 'Synthetic smoke' not in source,'Synthetic QA articles/fixtures are absent from production XML')
(ROOT/'tests/validation-results.json').write_text(json.dumps({'checks':len(results),'results':results,'scope':'Structural/XML/JS/CSS checks, not Blogger import acceptance'},ensure_ascii=False,indent=2))
print(len(results),'structural and syntax checks passed')
