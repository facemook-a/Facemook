"""Local QA renderer for this template's subset of Blogger XML.
This is test tooling, not Blogger and not evidence of Blogger import acceptance.
All articles/data below are explicit synthetic fixtures, never production XML.
"""
import datetime as dt
import html
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
B='{http://www.google.com/2005/gml/b}'
D='{http://www.google.com/2005/gml/data}'
X='{http://www.google.com/2005/gml/expr}'
H='{http://www.w3.org/1999/xhtml}'
def render(view='home', origin='http://127.0.0.1:8765', football=False, ads='', public=False):
    root=ET.parse(ROOT/'ARABIA-PRO-X-2026.xml').getroot()
    now=dt.datetime.now(dt.timezone.utc).isoformat()
    fixtures=[]
    for i in range(9):
        body='<img src="/test-image.svg" alt="صورة اختبار" width="1000" height="625"/>'
        body+=''.join(f'<h2>عنوان القراءة {n}</h2><p>'+('نص عربي اصطناعي لاختبار القراءة والتخطيط فقط. '*15)+'</p>' for n in range(12))
        body+='<h3>تفاصيل إضافية</h3><blockquote>اقتباس اختباري</blockquote><table><tr><th>العنوان الأول</th><th>English metric</th><th>قيمة</th></tr><tr><td>اختبار</td><td>1234</td><td>88</td></tr></table><pre><code>const example = true;</code></pre>'
        fixtures.append(dict(id=str(100+i),url=origin+'/post.html',title=['بين الفكرة والأثر: كيف نقرأ ملامح العالم الجديد؟','المدن الذكية ومساحات الحياة اليومية','الرياضة حين تروي حكاية المجتمع','جيل جديد من أدوات الإبداع الرقمي','اقتصاد المعرفة بين الفرصة والتحدي'][i%5],author='كاتب "اختبار"',authorProfileUrl=origin+'/author',authorAboutMe='',timestamp='29 أكتوبر 2026',timestampISO8601=now,firstImageUrl=origin+'/test-image.svg',isFirstPost=i==0,snippet='هذا المحتوى الاصطناعي لاختبار واجهة القالب فقط، ولا يدخل في ملف XML الإنتاجي.',body=body,labels=[dict(name='تكنولوجيا',url=origin+'/search/label/تكنولوجيا',count=5)],allowComments=True,numComments=1,comments=[dict(id='1',author='قارئ',authorUrl=origin+'/reader',timestamp='الآن',body='<p>تعليق اختباري.</p>')],embedCommentForm=True,commentFormIframeSrc=origin+'/comment-frame',addCommentUrl=origin+'/comment-frame',addCommentOnclick=''))
    page_type={'home':'index','post':'item','page':'static_page','matches':'static_page','search':'index','label':'index','archive':'archive','404':'error_page'}[view]
    blog={'title':'عربية برو إكس','description':'مجلة رقمية للمعرفة والأفكار وزوايا النظر الجديدة.','pageTitle':'عربية برو إكس — مختبر القالب','homepageUrl':origin+'/', 'url':origin+('/' if view=='home' else '/'+view+'.html'), 'pageType':page_type,'searchLabel':'تكنولوجيا' if view=='label' else '', 'searchQuery':'المدن' if view=='search' else '', 'metaDescription':'وصف اختبار','languageDirection':'rtl'}
    if view=='matches':fixtures[0]['body']='<div data-arx-fixtures="full"></div>';fixtures[0]['title']='مركز المباريات'
    if view=='page':fixtures[0]['title']='صفحة اختبار'
    config={'ads':{'enabled':bool(ads),'publisher':'ca-pub-1234567890123456' if ads else '', 'mode':ads or 'manual'},'football':{'mode':('public' if public else 'proxy') if football else 'off','endpoint':'https://fixtures.test/data' if football else '', 'sourceName':'مصدر الاختبار الاصطناعي','realtime':not public,'pollSeconds':120,'fixturesPage':origin+'/p/matches.html','allowedCompetitionIds':[],'crestHosts':[]}}
    base={'blog':blog,'posts':fixtures if view in ['home','search','label','archive'] else fixtures[:1],'olderPageUrl':origin+'/search?updated-max=2026','newerPageUrl':''}
    raw={'post.body','post.snippet','comment.body','content'}
    def resolve(path, context):
        path=path.removeprefix('data:')
        value=context
        for part in path.split('.'):
            value=value.get(part,'') if isinstance(value,dict) else ''
        return value
    def evaluate(expression,context):
        text=re.sub(r'data:([A-Za-z0-9_.]+)',lambda m:'resolve('+repr(m[1])+', context)',expression)
        return eval(text,{'__builtins__':{},'resolve':resolve,'context':context,'true':True,'false':False})
    def children(el,context):
        text=html.escape(el.text or '')
        attrs={}
        for child in el:
            result,extra=element(child,context);text+=result+html.escape(child.tail or '');attrs.update(extra)
        return text,attrs
    def element(el,context):
        tag=el.tag
        if not isinstance(tag,str):return '',{}
        if tag.startswith(D):
            key=tag[len(D):];value=resolve(key,context)
            return str(value) if key in raw else html.escape(str(value)),{}
        if tag==B+'includable' or tag==B+'widget-settings':return '',{}
        if tag==B+'if':
            branch=evaluate(el.get('cond'),context);switch=False;text='';attrs={}
            for child in el:
                if child.tag==B+'else':switch=True;continue
                if bool(branch)!=switch:
                    result,extra=element(child,context);text+=result+(child.tail or '');attrs.update(extra)
            return text,attrs
        if tag==B+'loop':
            text='';attrs={}
            for index,value in enumerate(evaluate(el.get('values'),context) or []):
                current={**context,el.get('var'):value,el.get('index','index'):index}
                result,extra=children(el,current);text+=result;attrs.update(extra)
            return text,attrs
        if tag==B+'attr':
            value=evaluate(el.get(X+'value'),context) if el.get(X+'value') else el.get('value','')
            return '',{el.get('name'):str(value)}
        if tag==B+'include':
            name=el.get('name')
            if name=='all-head-content':
                return '<link rel="canonical" href="'+html.escape(blog['url'])+'"/><meta property="og:title" content="مختبر القالب"/>',{}
            inc=current_includes[name]
            current=dict(context)
            if el.get('data'):current[inc.get('var','top')]=resolve(el.get('data'),context)
            return children(inc,current)
        if tag==B+'skin':
            css=el.text
            for key,value in {'keycolor':'#1264d8','accentcolor':'#087f8c','backgroundcolor':'#f7f9fc'}.items():css=css.replace('$('+key+')',value)
            return '<style>'+css+'</style>',{}
        if tag==B+'widget':
            typ=el.get('type');wid=el.get('id');current={**base,'title':el.get('title','')}
            if typ=='Header':current.update(title=blog['title'],useImage=False,sourceUrl='')
            if typ=='LinkList':current['links']=[{'name':n,'target':origin+'/search/label/'+n} for n in ['تكنولوجيا','رياضة','اقتصاد']]
            if typ=='Label':current['labels']=[{'name':n,'url':origin+'/search/label/'+n,'count':4} for n in ['تكنولوجيا','رياضة','اقتصاد','تعليم','حياة','أخبار']]
            if typ=='PopularPosts':current['posts']=[{'href':p['url'],'title':p['title']} for p in fixtures[:4]]
            if typ=='PageList':current['links']=[{'title':n,'href':origin+'/p/about.html'} for n in ['من نحن','اتصل بنا','سياسة الخصوصية','سياسة التحرير']]
            if typ=='HTML':
                content=el.find('.//'+B+'widget-setting[@name="content"]');current['content']=content.text or '' if content is not None else ''
                if wid=='HTML1':current['content']='<script type="application/json" id="arx-config">'+json.dumps(config)+'</script>'
                if ads and wid in ['HTML10','HTML12','HTML13','HTML14','HTML15','HTML16','HTML8','HTML11']:current['content']='<div class="arx-ad" data-ad-slot="1234567890" hidden="hidden"></div>'
            previous=dict(current_includes);current_includes.clear();current_includes.update({inc.get('id'):inc for inc in el.findall(B+'includable')})
            rendered,_=children(current_includes['main'],current)
            current_includes.clear();current_includes.update(previous)
            return '<div class="widget '+typ+'" id="'+wid+'">'+rendered+'</div>',{}
        if tag==B+'section':
            text,_=children(el,context);return '<div id="'+el.get('id')+'" class="'+el.get('class','')+'">'+text+'</div>',{}
        if tag.startswith(B):return '',{}
        local=tag.removeprefix(H)
        attributes={key:val for key,val in el.attrib.items() if not key.startswith('{')}
        for key,value in el.attrib.items():
            if key.startswith(X):attributes[key[len(X):]]=str(evaluate(value,context))
        if local in ['script','style']:
            content=el.text or '';extra={}
        else:content,extra=children(el,context)
        attributes.update(extra)
        attrs=''.join(' '+key+'="'+html.escape(str(value),quote=True)+'"' for key,value in attributes.items())
        if local in ['meta','link','img','input','br','hr','source','wbr']:return '<'+local+attrs+'>',{}
        return '<'+local+attrs+'>'+content+'</'+local+'>',{}
    current_includes={}
    return '<!DOCTYPE html>'+element(root,base)[0]
