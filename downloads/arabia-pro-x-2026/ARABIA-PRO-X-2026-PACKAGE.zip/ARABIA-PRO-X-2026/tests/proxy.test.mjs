import test from 'node:test';
import assert from 'node:assert/strict';
import worker,{refresh,normalize} from '../football-proxy/worker.mjs';
const fixture=(status='FT')=>({fixture:{id:42,date:'2026-10-29T20:00:00+01:00',status:{short:status}},league:{id:77,name:'Synthetic test competition',round:'Test round'},teams:{home:{id:1,name:'Test A'},away:{id:2,name:'Test B'}},goals:{home:0,away:2}});
const kv=()=>{const data=new Map();return {data,async get(key,format){const value=data.get(key);return format==='json'&&value?JSON.parse(value):value||null;},async put(key,value){data.set(key,value);}};};
test('Normalizes supplied timestamps to UTC, preserves zero scores and filters unauthorized leagues',()=>{
 const result=normalize([{response:[fixture(),{...fixture(),league:{id:88,name:'excluded'}}],errors:[]}],['77'],'2026-10-29T21:00:00Z',{});
 assert.equal(result.matches.length,1);assert.equal(result.matches[0].kickoff,'2026-10-29T19:00:00.000Z');assert.deepEqual(result.matches[0].score,{home:0,away:2});assert.equal(result.matches[0].status,'finished');
});
test('Provider errors reject normalization instead of becoming an empty success',()=>{
 assert.throws(()=>normalize([{response:[],errors:{plan:'unavailable'}}],['77'],new Date().toISOString(),{}));
});
test('Scheduled refresh sends server authentication and stores one deduplicated shared snapshot',async()=>{
 const cache=kv();const calls=[];const env={FOOTBALL_CACHE:cache,FOOTBALL_API_KEY:'synthetic-test-only',LEAGUE_IDS:'77',PAST_DAYS:'1',FUTURE_DAYS:'1'};
 const result=await refresh(env,async(url,options)=>{calls.push([String(url),options]);return Response.json({errors:[],response:[fixture('1H')]});},new Date('2026-10-29T10:00:00Z'));
 assert.equal(calls.length,3);assert.match(calls[0][0],/date=2026-10-28/);assert.equal(calls[0][1].headers['x-apisports-key'],'synthetic-test-only');assert.equal(result.matches.length,1);assert.equal(result.matches[0].status,'live');assert.equal(cache.data.size,1);assert.ok(!JSON.stringify(result).includes('synthetic-test-only'));
});
test('A failed update preserves the previous valid KV record',async()=>{
 const cache=kv();cache.data.set('fixtures:v1','previous');
 await assert.rejects(()=>refresh({FOOTBALL_CACHE:cache,FOOTBALL_API_KEY:'test-only',LEAGUE_IDS:'77'},async()=>new Response('',{status:429})));
 assert.equal(cache.data.get('fixtures:v1'),'previous');
});
test('Visitor reads use only shared KV, enforce origin, and expose no key',async()=>{
 const cache=kv();cache.data.set('fixtures:v1',JSON.stringify({matches:[],competitions:[],updatedAt:'2026-10-29T10:00:00Z'}));
 const env={FOOTBALL_CACHE:cache,ALLOWED_ORIGINS:'https://publisher.test',FOOTBALL_API_KEY:'never-public'};
 const response=await worker.fetch(new Request('https://worker.test/fixtures',{headers:{Origin:'https://publisher.test'}}),env);
 assert.equal(response.status,200);assert.equal(response.headers.get('Access-Control-Allow-Origin'),'https://publisher.test');assert.match(response.headers.get('Cache-Control'),/s-maxage/);assert.ok(!(await response.text()).includes('never-public'));
 assert.equal((await worker.fetch(new Request('https://worker.test/fixtures',{headers:{Origin:'https://other.test'}}),env)).status,403);
});
test('Missing snapshot is an explicit 503; unsupported methods and routes fail',async()=>{
 const env={FOOTBALL_CACHE:kv(),ALLOWED_ORIGINS:''};
 assert.equal((await worker.fetch(new Request('https://worker.test/fixtures'),env)).status,503);
 assert.equal((await worker.fetch(new Request('https://worker.test/fixtures',{method:'POST'}),env)).status,405);
 assert.equal((await worker.fetch(new Request('https://worker.test/unknown'),env)).status,404);
});
