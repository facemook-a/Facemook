"""Bundle the original assets into a standalone Blogger XML theme."""
from pathlib import Path
from xml.sax.saxutils import escape
import json

ROOT = Path(__file__).resolve().parent
CSS = (ROOT / 'src/theme.css').read_text() + '\n' + (ROOT / 'src/magazine.css').read_text()
JS = (ROOT / 'src/theme.js').read_text()
icons = {
    'menu': '<path d="M4 6h16M4 12h16M4 18h16"/>',
    'search': '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4 4"/>',
    'theme': '<path d="M20 14.5A8.4 8.4 0 0 1 9.5 4 8.5 8.5 0 1 0 20 14.5Z"/>',
    'chevron': '<path d="m6 9 6 6 6-6"/>',
    'close': '<path d="m6 6 12 12M6 18 18 6"/>',
    'up': '<path d="m6 13 6-6 6 6M12 7v13"/>',
    'brand': '<path d="m5 18 6-12h3l5 12M8 13h9M5 5h3"/>',
    'image': '<rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="8" cy="9" r="1"/><path d="m3 17 5-5 4 4 3-3 6 6"/>',
    'tag': '<path d="M20 13 13 20a2 2 0 0 1-3 0l-7-7V4h9l8 6a2 2 0 0 1 0 3Z"/><circle cx="7.5" cy="8" r="1"/>',
    'external': '<path d="M14 4h6v6M20 4l-9 9M9 4H5a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-4"/>',
}
def icon(name):
    return '<svg aria-hidden="true" class="icon" viewBox="0 0 24 24">' + icons[name] + '</svg>'

def section(id, contents, cls='', maxwidgets=12, add='yes'):
    return f'<b:section id="{id}" class="{cls}" maxwidgets="{maxwidgets}" showaddelement="{add}">{contents}</b:section>'

def widget(id, kind, title, main, settings='', locked='false'):
    settings_xml = ''
    if settings:
        settings_xml = '<b:widget-settings>' + ''.join(f'<b:widget-setting name="{key}"><![CDATA[{value}]]></b:widget-setting>' for key,value in settings.items()) + '</b:widget-settings>'
    return f'<b:widget id="{id}" type="{kind}" title="{escape(title)}" version="1" locked="{locked}" visible="true">{settings_xml}<b:includable id="main">{main}</b:includable></b:widget>'

def html_widget(number, title, content=''):
    return widget('HTML'+str(number), 'HTML',title,'<div class="widget-content"><data:content/></div>',{'content':content})

config = {
  'ads': {'enabled': False, 'publisher': '', 'mode': 'manual'},
  'football': {'mode': 'off', 'endpoint': '', 'sourceName': '', 'realtime': False,
               'pollSeconds': 120, 'fixturesPage': '', 'allowedCompetitionIds': [], 'crestHosts': []}
}
settings = section('themeSettings',html_widget(1,'إعدادات ARABIA PRO X', '<script id="arx-config" type="application/json">'+json.dumps(config,ensure_ascii=False,indent=2)+'</script>'),'configuration',1,'no')
header = section('siteIdentity',widget('Header1','Header','ARABIA PRO X',f'''<a class="brand" expr:href="data:blog.homepageUrl" rel="home">
<b:if cond="data:useImage"><img class="brand-image" expr:src="data:sourceUrl" expr:alt="data:title" width="180" height="48"/><b:else/>
<span class="brand-mark">{icon('brand')}</span><span><span class="brand-title"><data:title/></span><span class="brand-caption"><b:if cond='data:description != &quot;&quot;'><data:description/><b:else/>أخبار · رياضة · تقنية · زوايا جديدة</b:if></span></span></b:if></a>'''),'header',1,'no')
navigation = section('primaryLinks',widget('LinkList1','LinkList','القائمة الرئيسية','''<div class="widget-content"><ul><li><a expr:href="data:blog.homepageUrl">الرئيسية</a></li><b:loop values="data:links" var="link"><li><a expr:href="data:link.target"><data:link.name/></a></li></b:loop></ul></div>'''),'navigation',1,'no')
label_main = '''<b:if cond='data:title != &quot;&quot;'><h2><data:title/></h2></b:if><div class="label-links"><b:loop values="data:labels" var="label"><a expr:href="data:label.url"><data:label.name/><small><data:label.count/></small></a></b:loop></div>'''
mega = section('categoryLinks',widget('Label1','Label','استكشف الموضوعات',label_main),'labels',1,'no')
navigation_categories = section('navigationCategories',widget('Label3','Label','تصنيفات القائمة',f'''<ul class="category-nav-links"><b:loop values="data:labels" var="label"><li><a expr:href="data:label.url">{icon('tag')}<data:label.name/></a></li></b:loop></ul>'''),'navigation-categories',1,'no')
social = section('socialLinks',widget('LinkList2','LinkList','تابعنا',f'''<h2><data:title/></h2><div class="social-list"><b:loop values="data:links" var="link"><a expr:href="data:link.target" expr:aria-label="data:link.name" expr:data-network="data:link.name" rel="noopener noreferrer" target="_blank">{icon('external')}<span><data:link.name/></span></a></b:loop></div>'''),'social-links',1,'no')
latest = section('latestUpdates',html_widget(17,'أحدث المقالات','<section data-arx-latest="" data-title="أحدث المقالات" data-count="5" hidden="hidden"></section>'),'latest-updates',2)
sidebar = section('sidebar',widget('PopularPosts1','PopularPosts','الأكثر قراءة','''<h2><data:title/></h2><ol class="popular-list"><b:loop values="data:posts" var="post"><li><a expr:href="data:post.href" dir="auto"><b:if cond="data:post.thumbnail"><img expr:src="data:post.thumbnail" alt="" width="48" height="48" loading="lazy"/></b:if><span><data:post.title/></span></a></li></b:loop></ol>''') + widget('Label2','Label','الموضوعات',label_main) + html_widget(8,'إعلان — الشريط الجانبي') + html_widget(9,'إعلان تحريري أو نبذة'),'sidebar',12)
modules = ''
for number,label,title,layout in [(4,'تكنولوجيا','تكنولوجيا تصنع الغد','lead'),(5,'رياضة','من قلب الرياضة','rows'),(6,'اقتصاد','الاقتصاد والأعمال','grid'),(7,'اختيارات المحرر','اختيارات المحرر','lead')]:
    modules += html_widget(number,'قسم — '+label,f'<section data-arx-module="" data-label="{label}" data-title="{title}" data-layout="{layout}" data-count="4" hidden="hidden"></section>')
home_modules = section('homeModules',modules,'home-modules')
ads = ''.join(section(id,html_widget(num,title),'ad-section',1,'no') for id,num,title in [
    ('featuredAds',12,'إعلان — بعد المحتوى البارز'),('groupAds',13,'إعلان — بين مجموعات المقالات'),
    ('articleIntroAds',14,'إعلان — مقدمة المقال'),('articleInlineAds',15,'إعلان — داخل المقال الطويل'),('articleBelowAds',16,'إعلان — أسفل المقال')])
footerpages = section('trustPages',widget('PageList1','PageList','عن المنصة','''<h2><data:title/></h2><ul><b:loop values="data:links" var="link"><li><a expr:href="data:link.href"><data:link.title/></a></li></b:loop></ul>'''),'footer-links',2)

blog = r'''<b:section id="main" class="main" maxwidgets="1" showaddelement="no">
<b:widget id="Blog1" type="Blog" title="المقالات" version="1" locked="true" visible="true">
<b:includable id="main" var="top">
<b:if cond='data:blog.pageType == &quot;error_page&quot;'>
  <section class="not-found"><strong>404</strong><h1>هذه الصفحة غير موجودة</h1><p>قد يكون الرابط تغيّر. تصفّح آخر المقالات أو ابحث عن الموضوع.</p><a class="button primary" expr:href="data:blog.homepageUrl">العودة إلى الرئيسية</a><form class="search-form" expr:action='data:blog.homepageUrl + &quot;search&quot;' method="get"><label class="sr-only" for="error-search">البحث في الموقع</label><input id="error-search" name="q" placeholder="ما الذي تبحث عنه؟" required="required" type="search"/><button class="button" type="submit">بحث</button></form></section>
<b:else/>
<b:if cond='data:blog.pageType == &quot;item&quot; or data:blog.pageType == &quot;static_page&quot;'>
  <b:loop values="data:posts" var="post"><b:include data="post" name="article"/></b:loop>
<b:else/>
  <b:if cond='data:blog.url == data:blog.homepageUrl'><div data-home-featured=""><div class="feature-grid"><div class="feature-primary"><b:loop values="data:posts" var="post" index="i"><b:if cond="data:i == 0"><b:include data="post" name="card"/></b:if></b:loop></div><div class="feature-secondary"><b:loop values="data:posts" var="post" index="i"><b:if cond="data:i &gt; 0 and data:i &lt; 4"><b:include data="post" name="card"/></b:if></b:loop></div></div><div data-ad-anchor="featured"></div></div></b:if>
  <b:if cond='data:blog.url != data:blog.homepageUrl'><header class="archive-heading"><h1><b:if cond="data:blog.searchLabel">موضوع: <data:blog.searchLabel/><b:else/><b:if cond="data:blog.searchQuery">نتائج البحث: <data:blog.searchQuery/><b:else/>أرشيف المقالات</b:if></b:if></h1></header><b:else/><div class="section-heading"><h1>أهم الأخبار</h1><a expr:href='data:blog.homepageUrl + &quot;search&quot;'>كل المقالات ←</a></div></b:if>
  <b:if cond='data:blog.url == data:blog.homepageUrl'><div class="news-filters" data-news-filter-bar="" role="group" aria-label="تصفية الأخبار المعروضة حسب التصنيف" hidden="hidden"></div></b:if>
  <div class="editorial-grid"><b:loop values="data:posts" var="post" index="i"><b:if cond='data:blog.url != data:blog.homepageUrl or data:i &gt; 3'><b:include data="post" name="card"/></b:if></b:loop></div>
  <b:if cond="data:blog.searchQuery"><p class="status-message">تُعرض النتائج المطابقة المتاحة من Blogger. جرّب كلمات أخرى إذا لم تجد ما تبحث عنه.</p></b:if>
  <b:if cond='data:blog.url != data:blog.homepageUrl'><div data-ad-anchor="featured"></div></b:if>
</b:if>
<b:include name="pagination"/>
</b:if>
</b:includable>
<b:includable id="card" var="post">
<article class="story">
  <a class="story-media" expr:href="data:post.url" aria-hidden="true" tabindex="-1"><b:if cond="data:post.firstImageUrl"><img expr:src="data:post.firstImageUrl" alt="" width="800" height="500" decoding="async"><b:if cond="data:post.isFirstPost"><b:attr name="loading" value="eager"/><b:attr name="fetchpriority" value="high"/><b:else/><b:attr name="loading" value="lazy"/></b:if></img><b:else/><span class="no-image story-media">__IMAGE__</span></b:if></a>
  <div class="story-copy"><b:loop values="data:post.labels" var="label" index="i"><b:if cond="data:i == 0"><a class="pill" expr:href="data:label.url"><data:label.name/></a></b:if></b:loop><h2 dir="auto"><a expr:href="data:post.url"><data:post.title/></a></h2><div class="story-meta"><span><data:post.author/></span><span aria-hidden="true">·</span><time expr:datetime="data:post.timestampISO8601"><data:post.timestamp/></time></div><p class="story-summary"><data:post.snippet/></p></div>
</article>
</b:includable>
<b:includable id="article" var="post">
<article class="post"><b:if cond='data:blog.pageType == &quot;item&quot;'><b:attr name="data-kind" value="post"/><b:else/><b:attr name="data-kind" value="page"/></b:if>
<nav class="breadcrumbs" aria-label="مسار التصفح"><a expr:href="data:blog.homepageUrl">الرئيسية</a><b:loop values="data:post.labels" var="label" index="i"><b:if cond="data:i == 0"><span aria-hidden="true">/</span><a expr:href="data:label.url"><data:label.name/></a></b:if></b:loop></nav>
<header class="post-header"><h1 class="post-title" dir="auto"><data:post.title/></h1>
<b:if cond='data:blog.pageType == &quot;item&quot;'><div class="post-meta"><b:if cond="data:post.authorProfileUrl"><a class="author-name" expr:href="data:post.authorProfileUrl" rel="author"><data:post.author/></a><b:else/><span class="author-name"><data:post.author/></span></b:if><time expr:datetime="data:post.timestampISO8601"><data:post.timestamp/></time><span data-reading-time="" hidden="hidden"></span></div></b:if></header>
<div class="reading-tools js-only" aria-label="أدوات القراءة"><button class="button" data-font-size="1" type="button" aria-label="تكبير الخط">أ+</button><button class="button" data-font-size="-1" type="button" aria-label="تصغير الخط">أ−</button><button class="button" data-bookmark="" type="button" aria-pressed="false">حفظ للقراءة لاحقًا</button><button class="button" data-bookmarks-open="" type="button" aria-controls="bookmarks-dialog">المحفوظات</button></div>
<div data-ad-anchor="intro"></div>
<div class="post-body entry-content" expr:id='&quot;post-body-&quot; + data:post.id'><data:post.body/></div>
<div data-ad-anchor="below"></div>
<div class="share-tools js-only" aria-label="مشاركة الصفحة"><button class="button" data-copy-link="" type="button">نسخ الرابط</button><button class="button" data-native-share="" hidden="hidden" type="button">مشاركة</button><a class="button" data-share="whatsapp" hidden="hidden" target="_blank" rel="noopener noreferrer">واتساب</a><a class="button" data-share="x" hidden="hidden" target="_blank" rel="noopener noreferrer">X</a></div>
<b:if cond='data:blog.pageType == &quot;item&quot;'><aside class="author-box"><div><span class="eyebrow">بقلم</span><h2 style="font-size:18px;margin:3px 0"><b:if cond="data:post.authorProfileUrl"><a expr:href="data:post.authorProfileUrl" rel="author"><data:post.author/></a><b:else/><data:post.author/></b:if></h2><b:if cond="data:post.authorAboutMe"><p><data:post.authorAboutMe/></p></b:if></div></aside>
<section class="related module" data-related="" data-title="اقرأ أيضًا" data-count="6" hidden="hidden"><b:loop values="data:post.labels" var="label" index="i"><b:if cond="data:i == 0"><b:attr name="data-label" expr:value="data:label.name"/></b:if></b:loop></section></b:if>
<b:include data="post" name="comments"/>
</article>
</b:includable>
<b:includable id="pagination"><nav class="pagination" aria-label="التنقل بين المقالات"><b:if cond="data:newerPageUrl"><a class="button" expr:href="data:newerPageUrl" rel="prev">← الأحدث</a></b:if><a class="button" expr:href="data:blog.homepageUrl">الرئيسية</a><b:if cond="data:olderPageUrl"><a class="button" expr:href="data:olderPageUrl" rel="next">الأقدم →</a></b:if></nav></b:includable>
<b:includable id="comments" var="post">
<b:if cond="data:post.allowComments"><section class="comments" id="comments"><h2>التعليقات (<data:post.numComments/>)</h2><ol class="comment-list"><b:loop values="data:post.comments" var="comment"><li expr:id='&quot;comment-&quot; + data:comment.id'><strong><b:if cond="data:comment.authorUrl"><a expr:href="data:comment.authorUrl" rel="nofollow ugc"><data:comment.author/></a><b:else/><data:comment.author/></b:if></strong><div class="story-meta"><data:comment.timestamp/></div><div class="comment-body"><data:comment.body/></div></li></b:loop></ol>
<b:if cond="data:post.embedCommentForm"><iframe class="comment-frame" id="comment-editor" name="comment-editor" title="إضافة تعليق عبر Blogger" expr:src="data:post.commentFormIframeSrc" loading="lazy" width="100%" height="480" frameborder="0"></iframe><b:else/><a class="button" expr:href="data:post.addCommentUrl" expr:onclick="data:post.addCommentOnclick">إضافة تعليق عبر Blogger</a></b:if></section></b:if>
</b:includable>
</b:widget></b:section>'''.replace('__IMAGE__',icon('image'))

template = '''<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:b="http://www.google.com/2005/gml/b" xmlns:data="http://www.google.com/2005/gml/data" xmlns:expr="http://www.google.com/2005/gml/expr" b:version="2" b:layoutsVersion="3" b:defaultwidgetversion="1" b:css="false" b:responsive="true" lang="ar" dir="rtl">
<head>
<meta charset="UTF-8"/><meta name="viewport" content="width=device-width, initial-scale=1"/>
<b:include data="blog" name="all-head-content"/>
<title><data:blog.pageTitle/></title>
<link rel="home" expr:href="data:blog.homepageUrl"/>
<meta name="twitter:card" content="summary_large_image"/>
<meta name="twitter:title" expr:content="data:blog.pageTitle"/>
<b:if cond="data:blog.metaDescription"><meta name="twitter:description" expr:content="data:blog.metaDescription"/></b:if>
<link rel="preconnect" href="https://fonts.googleapis.com"/><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="anonymous"/>
<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800&amp;display=swap" rel="stylesheet"/>
<script><![CDATA[document.documentElement.classList.add('js');try{const t=localStorage.getItem('arx:theme');if(['light','dark','system'].includes(t))document.documentElement.dataset.theme=t;}catch(e){}]]></script>
<b:skin><![CDATA[
/*
<Group description="ARABIA PRO X — Colors" selector="body">
<Variable name="keycolor" description="Primary blue" type="color" default="#1264d8" value="#1264d8"/>
<Variable name="accentcolor" description="Secondary turquoise" type="color" default="#087f8c" value="#087f8c"/>
<Variable name="backgroundcolor" description="Page background" type="color" default="#f7f9fc" value="#f7f9fc"/>
</Group>
*/
__CSS__
.configuration{display:none}body#layout .configuration,body#layout .ad-staging{display:block!important}body#layout .page-layout{display:block}body#layout .sidebar{display:block}body#layout .site-header{position:static}body#layout .primary-nav{position:static;visibility:visible;transform:none}
]]></b:skin>
</head>
<body>
<b:if cond='data:blog.url == data:blog.homepageUrl'><b:attr name="data-view" value="home"/><b:else/><b:attr name="data-view" expr:value="data:blog.pageType"/></b:if>
<a class="skip-link" href="#main-content">انتقل إلى المحتوى</a><div class="reading-progress" id="reading-progress" aria-hidden="true"></div>
__SETTINGS__
<div class="top-strip"><div class="shell top-strip-inner"><div class="top-ticker">__BREAKING__</div><div class="top-meta"><span data-top-date=""></span><time data-top-time=""></time><div data-top-social="" class="top-social"></div></div></div></div>
<header class="site-header"><div class="shell header-inner masthead"><div class="masthead-options">
<details class="explore"><summary>الأقسام __CHEVRON__</summary><div class="explore-panel">__MEGA__</div></details>
<button class="icon-button js-only" data-theme-toggle="" type="button" aria-label="تبديل المظهر">__THEME__</button></div>__HEADER__
<div class="masthead-tools"><form class="masthead-search" expr:action='data:blog.homepageUrl + &quot;search&quot;' method="get"><label class="sr-only" for="header-search">البحث في الأخبار</label>__SEARCH__<input id="header-search" name="q" type="search" placeholder="ابحث عن أخبار، مباريات، مقالات…" required="required"/></form><button class="icon-button mobile-search js-only" data-search-open="" type="button" aria-label="فتح البحث" aria-controls="search-dialog">__SEARCH__</button><button class="icon-button menu-toggle js-only" data-menu-toggle="" type="button" aria-controls="primary-navigation" aria-expanded="false" aria-label="فتح القائمة">__MENU__</button></div></div>
<div class="blue-navigation"><div class="shell"><nav class="primary-nav" id="primary-navigation" aria-label="القائمة الرئيسية">__NAV____NAVCATEGORIES__</nav><nav class="mobile-category-bar" data-mobile-categories="" aria-label="روابط الأقسام السريعة"></nav></div></div></header>
<button class="drawer-backdrop" id="drawer-backdrop" type="button" tabindex="-1" aria-label="إغلاق القائمة"></button>
<div class="shell announcement">__ANNOUNCEMENT__</div>
<b:if cond='data:blog.url == data:blog.homepageUrl'><div class="shell"><section data-arx-fixtures="compact" hidden="hidden"></section></div></b:if>
<div class="shell">__LEADERBOARD__</div>
<b:if cond='data:blog.url == data:blog.homepageUrl'><div class="shell home-showcase" data-home-feature-slot=""></div></b:if>
<div class="shell page-layout"><main class="main-column" id="main-content" tabindex="-1">__BLOG__
<b:if cond='data:blog.url == data:blog.homepageUrl'><div data-ad-anchor="groups"></div>__MODULES__</b:if></main>
<aside class="right-rail" aria-label="محتوى إضافي">__SOCIAL____SIDEBAR__</aside><b:if cond='data:blog.url == data:blog.homepageUrl'><aside class="latest-rail" aria-label="أحدث المقالات">__LATEST__</aside></b:if></div>
<div class="ad-staging" hidden="hidden">__ADS__</div>
<footer class="site-footer"><div class="shell"><div class="footer-inner"><div class="footer-about"><a class="brand-title" expr:href="data:blog.homepageUrl"><data:blog.title/></a><p data-site-description=""></p></div>__PAGES__</div>__FOOTERAD__<div class="footer-bottom"><span>© <span data-year="">2026</span> <data:blog.title/></span><span lang="en" dir="ltr">ARABIA PRO X / 2026</span></div></div></footer>
<dialog class="search-dialog" id="search-dialog" aria-labelledby="search-title"><div class="dialog-head"><h2 id="search-title">ابحث عن زاوية جديدة</h2><button class="icon-button" data-dialog-close="" type="button" aria-label="إغلاق البحث">__CLOSE__</button></div><form class="search-form" expr:action='data:blog.homepageUrl + &quot;search&quot;' method="get"><label class="sr-only" for="site-search">كلمات البحث</label><input id="site-search" name="q" type="search" placeholder="مقال، فكرة، موضوع…" required="required"/><button class="button primary" type="submit">بحث</button></form><p class="status-message">تبحث هذه الأداة في مقالات المدونة المنشورة.</p></dialog>
<noscript><div class="shell"><form class="search-form" expr:action='data:blog.homepageUrl + &quot;search&quot;' method="get"><label for="nojs-search">البحث</label><input id="nojs-search" name="q" type="search" required="required"/><button class="button" type="submit">بحث</button></form></div></noscript>
<dialog class="lightbox" id="image-lightbox" aria-label="عارض صور المقال"><div class="dialog-head"><span>صورة المقال</span><button class="icon-button" data-dialog-close="" type="button" aria-label="إغلاق الصورة">__CLOSE__</button></div><img alt=""/><p></p></dialog>
<dialog class="search-dialog" id="bookmarks-dialog" aria-labelledby="bookmarks-title"><div class="dialog-head"><h2 id="bookmarks-title">مقالاتك المحفوظة</h2><button class="icon-button" data-dialog-close="" type="button" aria-label="إغلاق المحفوظات">__CLOSE__</button></div><div data-bookmarks-list=""></div><p class="status-message">تُحفظ على هذا المتصفح فقط، دون حساب أو مزامنة.</p></dialog>
<button class="icon-button to-top js-only" data-to-top="" type="button" aria-label="العودة إلى الأعلى" hidden="hidden">__UP__</button><div class="toast" id="arx-toast" role="status" aria-live="polite" hidden="hidden"></div>
<script><![CDATA[__JS__]]></script>
</body></html>
'''
parts = {'CSS':CSS.replace('--blue:#1264d8','--blue:$(keycolor)',1).replace('--turquoise:#087f8c','--turquoise:$(accentcolor)',1).replace('--bg:#f7f9fc','--bg:$(backgroundcolor)',1),'JS':JS,'SETTINGS':settings,'HEADER':header,'NAV':navigation,'NAVCATEGORIES':navigation_categories,'MEGA':mega,'SOCIAL':social,'LATEST':latest,'BLOG':blog,'MODULES':home_modules,'SIDEBAR':sidebar,'ADS':ads,'PAGES':footerpages,
 'ANNOUNCEMENT':section('announcements',html_widget(2,'إعلان تحريري'),'announcement',2),
 'BREAKING':section('breakingNews',html_widget(3,'آخر العناوين','<div data-arx-breaking="" data-title="آخر العناوين" hidden="hidden"></div>'),'breaking-section',1,'no'),
 'LEADERBOARD':section('leaderboardAds',html_widget(10,'إعلان — أعلى الصفحة'),'ad-section',1,'no'),
 'FOOTERAD':section('footerAds',html_widget(11,'إعلان — تذييل الصفحة'),'ad-section',1,'no')}
parts.update({k.upper():icon(k) for k in icons})
for key,value in parts.items(): template=template.replace('__'+key+'__',value)
assert '__JS__' not in template and '__CSS__' not in template
(ROOT/'ARABIA-PRO-X-2026.xml').write_text(template,encoding='utf-8')
print('Built ARABIA-PRO-X-2026.xml:',len(template.encode()),'bytes')
