extends CanvasLayer

var move_vector := Vector2.ZERO
var sprinting := false
var jump_requested := false
var quality := 1
var photo := false
var touch_id := -1
var look_id := -1
var stick_origin := Vector2.ZERO
var stick_point := Vector2.ZERO
var ui: Control
var touch_art: Control
var status: Label
var bearing: Label
var message: Label
var notice_time := 9.0
var quality_button: Button
var interact_button: Button
var info: PanelContainer
var clock := 0.0
var buttons: Array[Button] = []
var font := preload("res://assets/Arabic.ttf")

func _ready() -> void:
	ui = Control.new()
	ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui.mouse_filter=Control.MOUSE_FILTER_IGNORE
	add_child(ui)
	var theme := Theme.new()
	theme.default_font=font
	theme.default_font_size=16
	ui.theme=theme
	var top := PanelContainer.new()
	top.position=Vector2(24,22)
	top.size=Vector2(280,94)
	top.add_theme_stylebox_override("panel",_panel(Color(0.035,0.08,0.07,0.80),16))
	ui.add_child(top)
	var stack := VBoxContainer.new()
	stack.add_theme_constant_override("separation",2)
	top.add_child(stack)
	var title := Label.new()
	title.text="GOLDEN MEADOW"
	title.add_theme_font_size_override("font_size",23)
	title.add_theme_color_override("font_color",Color("edcf93"))
	stack.add_child(title)
	var subtitle := Label.new()
	subtitle.text="المروج الذهبية  ·  رحلة في النور"
	subtitle.add_theme_font_size_override("font_size",14)
	stack.add_child(subtitle)
	status=Label.new()
	status.add_theme_font_size_override("font_size",14)
	stack.add_child(status)
	bearing=Label.new()
	bearing.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	bearing.position=Vector2(-210,27)
	bearing.size=Vector2(420,30)
	bearing.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	bearing.add_theme_color_override("font_color",Color("ffe8b3"))
	bearing.add_theme_constant_override("outline_size",6)
	bearing.add_theme_color_override("font_outline_color",Color(0.035,0.06,0.05,0.9))
	ui.add_child(bearing)
	var tools := HBoxContainer.new()
	tools.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	tools.position=Vector2(-421,24)
	tools.add_theme_constant_override("separation",9)
	ui.add_child(tools)
	quality_button=_button("جودة: متوسطة",Vector2(132,44),cycle_quality)
	tools.add_child(quality_button)
	tools.add_child(_button("الصوت",Vector2(70,44),func(): get_parent().toggle_sound()))
	tools.add_child(_button("البيت",Vector2(65,44),func(): get_parent().return_home()))
	tools.add_child(_button("؟",Vector2(44,44),_toggle_help))
	var photo_button := _button("◉",Vector2(50,46),toggle_photo)
	photo_button.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	photo_button.position=Vector2(-76,82)
	# Keep a small exit target available in photo mode.
	add_child(photo_button)
	photo_button.theme=theme
	message=Label.new()
	message.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	message.position=Vector2(-380,-100)
	message.size=Vector2(760,60)
	message.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	message.add_theme_color_override("font_color",Color("fff0cd"))
	message.add_theme_constant_override("outline_size",5)
	message.add_theme_color_override("font_outline_color",Color(0.03,0.06,0.05,0.9))
	ui.add_child(message)
	announce("اكتشف المروج واجمع 6 شعلات نور  ·  اسحب يمين الشاشة للنظر")
	var sprint := _button("ركض",Vector2(76,62),func():
		sprinting=not sprinting)
	sprint.toggle_mode=true
	sprint.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
	sprint.position=Vector2(-204,-106)
	ui.add_child(sprint)
	var jump := _button("قفز",Vector2(88,88),func(): jump_requested=true)
	jump.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
	jump.position=Vector2(-114,-126)
	ui.add_child(jump)
	interact_button=_button("تفاعل · E",Vector2(190,54),func():
		if get_parent().activities:get_parent().activities.interact())
	interact_button.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
	interact_button.position=Vector2(-230,-210)
	ui.add_child(interact_button)
	var beach:=_button("الشاطئ",Vector2(88,46),func():get_parent().go_beach())
	beach.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	beach.position=Vector2(-174,82)
	ui.add_child(beach)
	# Empty control draws the analog stick; it does not intercept touch events.
	touch_art=Control.new()
	touch_art.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	touch_art.mouse_filter=Control.MOUSE_FILTER_IGNORE
	touch_art.draw.connect(_draw_stick)
	ui.add_child(touch_art)
	_make_help()

func _panel(color: Color,radius: int) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color=color
	style.set_corner_radius_all(radius)
	style.set_content_margin_all(13)
	style.border_color=Color(0.85,0.75,0.5,0.22)
	style.set_border_width_all(1)
	return style

func _button(text: String, size: Vector2, callback: Callable) -> Button:
	var button := Button.new()
	button.text=text
	button.custom_minimum_size=size
	button.focus_mode=Control.FOCUS_NONE
	button.add_theme_stylebox_override("normal",_panel(Color(0.06,0.12,0.10,0.78),14))
	button.add_theme_stylebox_override("hover",_panel(Color(0.16,0.24,0.17,0.94),14))
	button.add_theme_stylebox_override("pressed",_panel(Color(0.38,0.40,0.22,0.94),14))
	button.add_theme_color_override("font_color",Color("f8e8c4"))
	button.pressed.connect(callback)
	buttons.append(button)
	return button

func _make_help() -> void:
	info=PanelContainer.new()
	info.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	info.position=Vector2(-270,-190)
	info.size=Vector2(540,380)
	info.add_theme_stylebox_override("panel",_panel(Color(0.035,0.07,0.06,0.97),22))
	ui.add_child(info)
	var content := VBoxContainer.new()
	content.add_theme_constant_override("separation",13)
	info.add_child(content)
	var label := Label.new()
	label.text="مرحباً بك في المروج الذهبية\n\nتجول في القرية والشاطئ واجمع شعلات النور.\nاقترب من الباب واضغط تفاعل لفتحه أو إغلاقه.\nعلى الشاطئ: تفاعل مع الشخصيات للمرافقة أو إيقافها.\n\nالهاتف: عصا يساراً، اسحب يميناً، قفز وركض.\nالحاسوب: WASD، الفأرة اليمنى للنظر، Space للقفز.\nShift للركض · E للتفاعل · R للبيت · Q للجودة.\nزر الشاطئ ينقلك إلى البحر، ويمكنك الوصول سيراً شرقاً.\nاختر جودة منخفضة إذا كان هاتفك بطيئاً."
	label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	label.add_theme_font_size_override("font_size",17)
	content.add_child(label)
	content.add_child(_button("انطلق",Vector2(0,44),_toggle_help))
	info.visible=false

func _toggle_help() -> void:
	info.visible=not info.visible
	move_vector=Vector2.ZERO
	touch_id=-1
	look_id=-1

func announce(text: String) -> void:
	message.text=text
	notice_time=7.0

func cycle_quality() -> void:
	quality=(quality+1)%3
	quality_button.text="جودة: "+["منخفضة","متوسطة","عالية"][quality]
	get_parent().set_quality(quality)

func toggle_photo() -> void:
	photo=not photo
	ui.visible=not photo

func _input(event: InputEvent) -> void:
	# Handle each touch explicitly, so buttons and two simultaneous fingers
	# work without converting the first finger into a mouse pointer.
	if event is InputEventScreenTouch and event.pressed:
		for button in buttons:
			if button.is_visible_in_tree() and button.get_global_rect().has_point(event.position):
				if button.toggle_mode: button.button_pressed=not button.button_pressed
				button.pressed.emit()
				get_viewport().set_input_as_handled()
				return
	if info.visible: return
	var size := get_viewport().get_visible_rect().size
	if event is InputEventScreenTouch:
		if event.pressed:
			if event.position.x<size.x*0.42 and event.position.y>size.y*0.35 and touch_id==-1:
				touch_id=event.index
				stick_origin=event.position
				stick_point=event.position
			elif look_id==-1:
				look_id=event.index
		else:
			if event.index==touch_id:
				touch_id=-1
				move_vector=Vector2.ZERO
			if event.index==look_id: look_id=-1
	if event is InputEventScreenDrag:
		if event.index==touch_id:
			stick_point=event.position
			move_vector=((stick_point-stick_origin)/62.0).limit_length(1.0)
		if event.index==look_id: get_parent().player.look(event.relative*0.004)
	touch_art.queue_redraw()

func _draw_stick() -> void:
	var size := get_viewport().get_visible_rect().size
	var origin := stick_origin if touch_id!=-1 else Vector2(119,size.y-121)
	touch_art.draw_circle(origin,63.0,Color(0.07,0.14,0.10,0.28))
	touch_art.draw_arc(origin,63.0,0,TAU,60,Color(0.94,0.87,0.63,0.35),1.5,true)
	touch_art.draw_circle(origin+move_vector*43.0,24.0,Color(0.94,0.87,0.63,0.33))

func _process(delta: float) -> void:
	clock+=delta
	notice_time-=delta
	message.modulate.a=clampf(notice_time,0.0,1.0)
	if clock<0.15: return
	clock=0.0
	var world := get_parent()
	if world.activities:interact_button.text=world.activities.interaction_text()
	var p: Vector3=world.player.position
	status.text="شعلات النور  \u2066%d / 6\u2069     ·     %.0f ، %.0f" % [world.collected.size(),p.x,-p.z]
	if world.collected.size()<6:
		var target: Vector3=world.nearest_wisp()
		var direction := target-p
		var angle := wrapf(atan2(-direction.x,-direction.z)-world.player.yaw,-PI,PI)
		var arrow := "↑" if absf(angle)<0.35 else ("←" if angle>0 else "→")
		bearing.text="%s   أقرب شعلة   %.0f م" % [arrow,Vector2(direction.x,direction.z).length()]
	else: bearing.text="✦  المروج مفتوحة لك  ✦"
	touch_art.queue_redraw()

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT:
		move_vector=Vector2.ZERO
		touch_id=-1
		look_id=-1
