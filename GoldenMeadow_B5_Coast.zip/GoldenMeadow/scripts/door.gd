extends Node3D
var opened := false
var speaker: AudioStreamPlayer3D
func _ready() -> void:
	speaker=AudioStreamPlayer3D.new()
	speaker.stream=load("res://assets/audio/door.wav")
	speaker.max_distance=18.0
	speaker.volume_db=-5
	add_child(speaker)
func interact() -> void:
	opened=not opened
	var tween:=create_tween()
	tween.tween_property(self,"rotation:y",-1.65 if opened else 0.0,0.5).set_trans(Tween.TRANS_SINE)
	speaker.play()
