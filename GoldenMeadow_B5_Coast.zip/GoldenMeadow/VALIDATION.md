# Validation

Godot 4.6.3 stable, Linux Compatibility renderer.

The updated smoke suite passes 28 gameplay checks, including movement and jump/landing, dispatched multitouch joystick/camera and jump button events, bounded terrain/grass streaming, quality changes, nine interactive cottage doors, opening the door and walking inside, solid beach terrain after teleport, three adult companion models, starting/following/stopping companionship, moving birds, running ocean ambience, six collectibles, and local save persistence.

Rendering was exercised with Mesa llvmpipe on a virtual display, including the ocean shader, closer camera and B5 avatar. Preview files are actual game captures. Android hardware and Godot 4.7.2 were not tested. Use low quality on weaker phones. Godot prints a resource-cleanup warning at process exit in this test environment; the gameplay assertions complete.

Models, ocean, cloth, companions and animations are simplified prototypes; the photorealistic reference image is not reproduced. Dialogues are text only. Character position and collectibles persist; door and companion states restart with each game session.
